import type { Metadata } from "next";
import Image from "next/image";
import Link from "next/link";
import { notFound } from "next/navigation";
import InsightCard from "@/app/components/InsightCard";
import InsightsHeader from "@/app/components/InsightsHeader";
import { insightContent } from "@/app/data/insight-content";
import { getInsight, insights } from "@/app/data/insights";

const siteUrl = "https://www.networkxcircle.com";

export function generateStaticParams() {
  return insights.map(({ slug }) => ({ slug }));
}

export async function generateMetadata({ params }: { params: Promise<{ slug: string }> }): Promise<Metadata> {
  const { slug } = await params;
  const insight = getInsight(slug);
  if (!insight) return {};
  const canonical = `${siteUrl}/insights/${insight.slug}`;
  return {
    title: insight.seoTitle,
    description: insight.metaDescription,
    keywords: [insight.primaryKeyword, ...insight.secondaryKeywords],
    alternates: { canonical },
    openGraph: { title: insight.seoTitle, description: insight.metaDescription, url: canonical, type: "article", images: [{ url: `${siteUrl}${insight.ogImage}`, alt: insight.title }] },
    twitter: { card: "summary_large_image", title: insight.seoTitle, description: insight.metaDescription, images: [`${siteUrl}${insight.ogImage}`] },
  };
}

export default async function InsightArticlePage({ params }: { params: Promise<{ slug: string }> }) {
  const { slug } = await params;
  const insight = getInsight(slug);
  if (!insight) notFound();
  const content = insightContent[slug];
  if (!content) notFound();
  const related = insights.filter((item) => item.slug !== slug).slice(0, 3);
  const canonical = `${siteUrl}/insights/${insight.slug}`;
  const structuredData = {
    "@context": "https://schema.org",
    "@type": "BlogPosting",
    headline: insight.h1,
    description: insight.metaDescription,
    image: `${siteUrl}${insight.ogImage}`,
    author: { "@type": "Organization", name: "NetworkX" },
    publisher: { "@type": "Organization", name: "NetworkX", logo: { "@type": "ImageObject", url: `${siteUrl}/brand/networkx-logo-header.png` } },
    mainEntityOfPage: canonical,
  };

  return (
    <main className="insights-page insight-article-page">
      <InsightsHeader />
      <script type="application/ld+json" dangerouslySetInnerHTML={{ __html: JSON.stringify(structuredData) }} />
      <article className="insight-article">
        <nav className="insight-breadcrumbs" aria-label="Breadcrumb"><Link href="/">Home</Link><span>/</span><Link href="/insights">Insights</Link><span>/</span><b>{insight.category}</b></nav>
        <header className="insight-article-header">
          <span className="insight-article-category">{insight.category}</span>
          <h1>{insight.h1}</h1>
          <p>{insight.excerpt}</p>
          <div><span>By NetworkX</span><i /> <span>{insight.readingTime}</span></div>
        </header>
        <div className="insight-article-cover"><Image src={insight.cover} alt={`${insight.title} cover illustration`} fill priority sizes="(max-width: 900px) 100vw, 1080px" /></div>
        <div className="insight-article-body">
          {content.map((section, index) => (
            <section key={`${section.heading ?? "introduction"}-${index}`}>
              {section.heading && <h2>{section.heading}</h2>}
              {section.paragraphs?.map((paragraph) => <p key={paragraph}>{paragraph}</p>)}
              {section.list && <ul>{section.list.map((item) => <li key={item}>{item}</li>)}</ul>}
              {section.emphasis && <blockquote>{section.emphasis}</blockquote>}
            </section>
          ))}
          <nav className="insight-topic-links" aria-label="Explore NetworkX features">
            <span>Explore related NetworkX experiences</span>
            <div><Link href="/#solutions">AI matchmaking</Link><Link href="/#global-community">Global community</Link><Link href="/#membership">Memberships</Link></div>
          </nav>
          <aside className="insight-inline-cta"><span>Explore NetworkX</span><h2>Build smarter connections and discover relevant opportunities.</h2><Link href="/#membership">Explore Memberships →</Link></aside>
        </div>
      </article>
      <section className="related-insights"><header><span>Keep exploring</span><h2>Related insights</h2></header><div>{related.map((item) => <InsightCard insight={item} key={item.slug} />)}</div></section>
    </main>
  );
}
