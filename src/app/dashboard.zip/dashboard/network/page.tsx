'use client'
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome'
import { faComment, faClock } from '@fortawesome/free-solid-svg-icons'
import { useState, useEffect } from 'react'
import { ConnectionsAPI } from '@/lib/api'
import { Loading, ApiError, Empty } from '@/components/shared/States'

export default function NetworkPage() {
  const [data, setData] = useState<any>({connected:[],pending_sent:[],pending_received:[],counts:{}})
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState('')
  const [msg, setMsg] = useState('')
  const [tab, setTab] = useState<'connected'|'pending_received'|'pending_sent'>('connected')
  const [busyId, setBusyId] = useState<string|null>(null)

  const fetchAll = async () => {
    setLoading(true); setError('')
    try { setData(await ConnectionsAPI.list()) }
    catch (e: any) { setError(e.message) }
    finally { setLoading(false) }
  }

  useEffect(() => { fetchAll() }, [])

  const respond = async (id: string, accept: boolean) => {
    setBusyId(id)
    try {
      accept ? await ConnectionsAPI.accept(id) : await ConnectionsAPI.decline(id)
      setMsg(accept ? '✅ Connection accepted!' : '✅ Request declined')
      fetchAll()
    } catch (e: any) { setMsg('❌ ' + e.message) }
    finally { setBusyId(null) }
  }

  const remove = async (id: string) => {
    if (!confirm('Remove this connection?')) return
    setBusyId(id)
    try { await ConnectionsAPI.remove(id); setMsg('✅ Connection removed'); fetchAll() }
    catch (e: any) { setMsg('❌ ' + e.message) }
    finally { setBusyId(null) }
  }

  const list = data[tab] || []

  return (
    <div className="page">
      <div style={{marginBottom:16}}>
        <h2 style={{fontSize:18,fontWeight:800}}>My Network</h2>
        <p style={{fontSize:13,color:'#9ca3af'}}>Manage connections and requests</p>
      </div>

      {msg && (
        <div className="toast-in" style={{padding:'10px 14px',borderRadius:10,marginBottom:12,fontSize:13,
          background:msg.startsWith('✅')?'rgba(39,216,109,.1)':'rgba(255,90,90,.1)',
          color:msg.startsWith('✅')?'#16a34a':'#ef4444',
          border:`1px solid ${msg.startsWith('✅')?'rgba(39,216,109,.35)':'rgba(255,90,90,.35)'}`}}>
          {msg}<button style={{marginLeft:12,background:'none',border:'none',cursor:'pointer',color:'#9ca3af'}} onClick={()=>setMsg('')}>✕</button>
        </div>
      )}

      <div style={{display:'grid',gridTemplateColumns:'repeat(3,1fr)',gap:12,marginBottom:16}}>
        {[
          {l:'Connections',v:data.counts?.connected||0,c:'#10b981',t:'connected'},
          {l:'Pending Requests',v:data.counts?.pending_received||0,c:'#f59e0b',t:'pending_received'},
          {l:'Sent',v:data.counts?.pending_sent||0,c:'#6366f1',t:'pending_sent'},
        ].map(s=>(
          <div key={s.l} onClick={()=>setTab(s.t as any)} style={{cursor:'pointer',background:tab===s.t?`linear-gradient(135deg,${s.c},${s.c}cc)`:'#fff',border:tab===s.t?'none':'1px solid #e5e7eb',borderRadius:12,padding:'14px 16px'}}>
            <div style={{fontSize:24,fontWeight:800,color:tab===s.t?'#fff':'var(--nx-ink)'}}>{s.v}</div>
            <div style={{fontSize:12,color:tab===s.t?'rgba(255,255,255,.85)':'#9ca3af',marginTop:4}}>{s.l}</div>
          </div>
        ))}
      </div>

      {loading ? <Loading label="Loading your network…"/> : error ? <ApiError message={error} onRetry={fetchAll}/> :
       list.length === 0 ? <Empty label={tab==='connected'?'No connections yet — head to Explore NetworkX to find members':tab==='pending_received'?'No pending requests':'No sent requests waiting'}/> : (
        <div style={{display:'flex',flexDirection:'column',gap:10}}>
          {list.map((c:any)=>(
            <div key={c.id} className="card" style={{display:'flex',alignItems:'center',gap:12}}>
              <div style={{width:44,height:44,borderRadius:'50%',background:'#6366f1',display:'flex',alignItems:'center',justifyContent:'center',color:'#fff',fontWeight:700,flexShrink:0}}>
                {c.user?.name?.charAt(0)||'?'}
              </div>
              <div style={{flex:1}}>
                <div style={{fontWeight:700,fontSize:14}}>{c.user?.name||'—'}</div>
                <div style={{fontSize:12,color:'#9ca3af'}}>{c.user?.city||''}</div>
              </div>
              <div style={{display:'flex',gap:6}}>
                {tab==='connected' && <>
                  <button className="btn btn-g btn-sm" onClick={()=>window.location.href=`/dashboard/messages?to=${c.other_user_id}&name=${encodeURIComponent(c.user?.name||'')}`}><FontAwesomeIcon icon={faComment} className="mr-1.5"/>Message</button>
                  <button className="btn btn-g btn-sm" style={{color:'#ef4444'}} onClick={()=>remove(c.id)} disabled={busyId===c.id}>Remove</button>
                </>}
                {tab==='pending_received' && <>
                  <button className="btn btn-p btn-sm" onClick={()=>respond(c.id,true)} disabled={busyId===c.id}>Accept</button>
                  <button className="btn btn-g btn-sm" onClick={()=>respond(c.id,false)} disabled={busyId===c.id}>Decline</button>
                </>}
                {tab==='pending_sent' && <span style={{fontSize:12,color:'#9ca3af'}}><FontAwesomeIcon icon={faClock} className="mr-1"/>Waiting for response</span>}
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  )
}
