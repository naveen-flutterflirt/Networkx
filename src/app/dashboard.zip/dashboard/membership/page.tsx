'use client'
import { useState, useEffect } from 'react'
import { MembersAPI, PaymentsAPI, TokenStore } from '@/lib/api'
import { Loading, ApiError } from '@/components/shared/States'
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome'
import { faStar } from '@fortawesome/free-solid-svg-icons'

const TIER_LABELS: Record<string,string> = {
  connect: 'Connect', growth: 'Growth', elite: 'Elite',
  city_leadership: 'City Leadership', national: 'National', global: 'Global',
}
// Grouping (Digital/Physical) uses each tier's own `type` field from the
// API, not a hardcoded id list — a hardcoded list silently hides any
// custom tier HQ creates later.

// Renders a raw benefit-matrix cell value as it actually came back from the
// API — no reinterpretation, so it never shows something the spreadsheet
// didn't say.
function BenefitCell({ value }: { value: any }) {
  if (value === null || value === undefined || value === '') return <span style={{color:'var(--nx-line)'}}>—</span>
  if (value === '✅') return <span style={{color:'#10b981',fontWeight:700}}>✅</span>
  if (value === '❌') return <span style={{color:'var(--nx-line)'}}>❌</span>
  if (typeof value === 'number') return <span>{Math.round(value*100)}%</span>
  return <span style={{fontSize:12}}>{value}</span>
}

function formatDate(d: any) {
  if (!d) return null
  try {
    // Firestore timestamps sometimes arrive as {seconds,...} or ISO strings
    // depending on serializer — handle both without guessing at a format
    // the backend never promised.
    const date = typeof d === 'object' && d.seconds ? new Date(d.seconds * 1000) : new Date(d)
    if (isNaN(date.getTime())) return null
    return date.toLocaleDateString('en-IN', { day: 'numeric', month: 'short', year: 'numeric' })
  } catch { return null }
}

// Loads Razorpay's checkout script once and reuses it — same script tag
// approach used by any other Razorpay-integrated page in the app.
function loadRazorpayScript(): Promise<boolean> {
  return new Promise((resolve) => {
    if ((window as any).Razorpay) return resolve(true)
    const existing = document.getElementById('razorpay-checkout-js')
    if (existing) {
      existing.addEventListener('load', () => resolve(true))
      existing.addEventListener('error', () => resolve(false))
      return
    }
    const script = document.createElement('script')
    script.id = 'razorpay-checkout-js'
    script.src = 'https://checkout.razorpay.com/v1/checkout.js'
    script.onload = () => resolve(true)
    script.onerror = () => resolve(false)
    document.body.appendChild(script)
  })
}

export default function MembershipPage() {
  const me = TokenStore.getUser()
  const [tiers, setTiers] = useState<any[]>([])
  const [myMembership, setMyMembership] = useState<any|null>(null)
  const [spotlight, setSpotlight] = useState<any[]>([])
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState('')
  const [showCompare, setShowCompare] = useState(false)
  const [upgrading, setUpgrading] = useState<string|null>(null)   // tier id currently mid-checkout
  const [upgradeError, setUpgradeError] = useState('')

  const fetchData = async () => {
    setLoading(true); setError('')
    try {
      const [tiersRes, mineRes, spotlightRes] = await Promise.all([
        MembersAPI.tiers(),
        MembersAPI.list({ page: 1, page_size: 5 }).catch(()=>({ items: [] })),
        MembersAPI.spotlight().catch(()=>({ items: [] })),
      ])
      setTiers(tiersRes.items || tiersRes || [])
      const mine = (mineRes.items || mineRes || []).find((m:any)=>m.user_id===me?.id) || (mineRes.items||mineRes||[])[0]
      setMyMembership(mine || null)
      setSpotlight(spotlightRes.items || spotlightRes || [])
    } catch (e: any) { setError(e.message) }
    finally { setLoading(false) }
  }

  useEffect(() => { fetchData() }, [])

  if (loading) return <div className="page"><Loading label="Loading membership tiers…"/></div>
  if (error) return <div className="page"><ApiError message={error} onRetry={fetchData}/></div>

  const featureKeys = tiers[0] ? Object.keys(tiers[0].benefits || {}) : []
  // Physical tiers (city_leadership/national/global) are ignored for now —
  // pricing on those is still "TBD" in the source data anyway, so there's
  // nothing actionable to show a member yet. Filtering by `type` (not a
  // hardcoded id list) means this naturally includes any new Digital
  // custom tier HQ creates later.
  const digitalTiers = tiers.filter(t => (t.type || '').toLowerCase() === 'digital')
  const myTier = myMembership?.tier

  const myTierIndex = digitalTiers.findIndex(t => t.tier === myTier)

  const openCompare = () => setShowCompare(true)

  // Tiers ranked strictly above the member's current tier, in the backend's
  // own ALL_TIERS order (connect < growth < elite) — that ordering comes
  // from `digitalTiers` array position, not re-derived here, so it stays
  // correct if HQ adds a custom Digital tier.
  const upgradeOptions = myTierIndex >= 0 ? digitalTiers.slice(myTierIndex + 1) : []

  const handleUpgrade = async (tier: any) => {
    setUpgradeError('')
    if (tier.price_numeric === null || tier.price_numeric === undefined) {
      setUpgradeError(`${TIER_LABELS[tier.tier] || tier.tier} pricing is not published yet — please reach out to your Franchise/HQ for this tier.`)
      return
    }
    setUpgrading(tier.tier)
    try {
      const order = await PaymentsAPI.createOrder({
        amount: tier.price_numeric,
        currency: 'INR',
        reference_type: 'membership',
        reference_id: tier.tier,
        plan: myMembership?.plan || 'yearly',
      })

      // Manual-entry deployments (no Razorpay key configured) skip
      // checkout entirely — createOrder already marks it paid.
      if (order.status === 'success') {
        await fetchData()
        setUpgrading(null)
        return
      }

      const scriptLoaded = await loadRazorpayScript()
      if (!scriptLoaded) throw new Error('Could not load payment gateway — please check your connection and try again.')

      const rzp = new (window as any).Razorpay({
        key: order.key,
        amount: Math.round(tier.price_numeric * 100), // paise
        currency: order.currency || 'INR',
        name: 'NetworkX',
        description: `Upgrade to ${TIER_LABELS[tier.tier] || tier.tier}`,
        order_id: order.gateway_order_id,
        prefill: { name: me?.name, email: me?.email, contact: me?.phone },
        theme: { color: '#ff5a1f' },
        handler: async (response: any) => {
          try {
            await PaymentsAPI.verify({
              payment_id: order.payment_id,
              razorpay_order_id: response.razorpay_order_id,
              razorpay_payment_id: response.razorpay_payment_id,
              razorpay_signature: response.razorpay_signature,
            })
            await fetchData()
          } catch (e: any) {
            setUpgradeError(e.message || 'Payment verification failed — if any amount was deducted, it will be reconciled automatically.')
          } finally {
            setUpgrading(null)
          }
        },
        modal: { ondismiss: () => setUpgrading(null) },
      })
      rzp.on('payment.failed', (resp: any) => {
        setUpgradeError(resp?.error?.description || 'Payment failed — please try again.')
        setUpgrading(null)
      })
      rzp.open()
    } catch (e: any) {
      setUpgradeError(e.message || 'Could not start the upgrade — please try again.')
      setUpgrading(null)
    }
  }

  return (
    <div className="page">
      <div style={{marginBottom:16}}>
        <h2 style={{fontSize:18,fontWeight:800}}>NetworkX Membership</h2>
        <p style={{fontSize:13,color:'var(--nx-muted)'}}>Compare tiers and see exactly what your plan unlocks</p>
      </div>

      {myMembership && (
        <div className="card" style={{borderLeft:'3px solid var(--nx-orange)',marginBottom:16,display:'flex',justifyContent:'space-between',alignItems:'center',flexWrap:'wrap',gap:12}}>
          <div>
            <div style={{fontSize:12,color:'var(--nx-muted)'}}>Your current tier</div>
            <div style={{fontSize:18,fontWeight:800,color:'var(--nx-orange)'}}>{TIER_LABELS[myTier] || myTier || 'Not set yet'}</div>
            <div style={{display:'flex',gap:14,marginTop:6,flexWrap:'wrap'}}>
              {formatDate(myMembership.joined_date) && (
                <div style={{fontSize:11,color:'var(--nx-muted)'}}>Member since <span style={{color:'var(--nx-ink)',fontWeight:600}}>{formatDate(myMembership.joined_date)}</span></div>
              )}
              {formatDate(myMembership.renewal_date) ? (
                <div style={{fontSize:11,color:'var(--nx-muted)'}}>Valid till <span style={{color:'var(--nx-ink)',fontWeight:600}}>{formatDate(myMembership.renewal_date)}</span></div>
              ) : (
                <div style={{fontSize:11,color:'var(--nx-muted)'}}>Validity not set — contact your coordinator</div>
              )}
            </div>
          </div>
          <div style={{display:'flex',alignItems:'center',gap:10}}>
            {myMembership.status && <span className={`badge ${myMembership.status==='active'?'b-green':myMembership.status==='warning'?'b-yellow':'b-red'}`}>{myMembership.status}</span>}
            <button className="btn btn-sm btn-g" onClick={openCompare}>Compare tiers</button>
          </div>
        </div>
      )}

      {!myMembership && (
        <div style={{display:'flex',justifyContent:'flex-end',marginBottom:16}}>
          <button className="btn btn-sm btn-g" onClick={openCompare}>Compare tiers</button>
        </div>
      )}

      {spotlight.length > 0 && (
        <div style={{marginBottom:16}}>
          <div style={{fontSize:13,fontWeight:700,marginBottom:8}}><FontAwesomeIcon icon={faStar} className="mr-1.5"/>Member Spotlight</div>
          <div style={{display:'flex',gap:10,overflowX:'auto',paddingBottom:4}}>
            {spotlight.map((s:any)=>(
              <div key={s.id} className="card" style={{minWidth:180,flexShrink:0,textAlign:'center'}}>
                <div style={{width:44,height:44,borderRadius:'50%',background:'#6366f1',display:'flex',alignItems:'center',justifyContent:'center',color:'#fff',fontWeight:700,margin:'0 auto 8px'}}>
                  {s.user?.name?.charAt(0)||'?'}
                </div>
                <div style={{fontSize:13,fontWeight:700}}>{s.user?.name||'NIA Member'}</div>
                {s.spotlight_note && <div style={{fontSize:11,color:'var(--nx-muted)',marginTop:4}}>{s.spotlight_note}</div>}
              </div>
            ))}
          </div>
        </div>
      )}

      {showCompare && (
        <div className="overlay" onClick={e=>e.target===e.currentTarget&&setShowCompare(false)}>
          <div className="modal modal-lg">
            <div style={{display:'flex',justifyContent:'space-between',alignItems:'center',marginBottom:14}}>
              <h3 style={{fontSize:16,fontWeight:700}}>Compare tiers</h3>
              <button className="btn btn-xs btn-g" onClick={()=>setShowCompare(false)}>✕</button>
            </div>

            <div style={{overflowX:'auto',maxHeight:420,overflowY:'auto'}}>
              <table className="tbl" style={{minWidth:600}}>
                <thead>
                  <tr>
                    <th>Benefit</th>
                    {digitalTiers.map(t=>(
                      <th key={t.tier} style={{color:t.tier===myTier?'var(--nx-orange)':undefined}}>
                        {TIER_LABELS[t.tier]||t.tier}{t.tier===myTier && ' (You)'}
                      </th>
                    ))}
                  </tr>
                  <tr>
                    <td style={{fontWeight:700,color:'var(--nx-muted)'}}>Annual Fee</td>
                    {digitalTiers.map(t=><td key={t.tier} style={{fontWeight:700,background:t.tier===myTier?'rgba(255,90,31,.1)':undefined}}>{t.price}</td>)}
                  </tr>
                </thead>
                <tbody>
                  {featureKeys.map(fk=>(
                    <tr key={fk}>
                      <td style={{fontSize:12,color:'var(--nx-muted)',maxWidth:260}}>{fk}</td>
                      {digitalTiers.map(t=>(
                        <td key={t.tier} style={{background:t.tier===myTier?'rgba(255,90,31,.1)':undefined}}>
                          <BenefitCell value={t.benefits?.[fk]}/>
                        </td>
                      ))}
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>

            <button className="btn btn-g" style={{width:'100%',marginTop:14}} onClick={()=>setShowCompare(false)}>Close</button>
          </div>
        </div>
      )}

      {myMembership && upgradeOptions.length > 0 && (
        <div style={{marginTop:20}}>
          <div style={{fontSize:13,fontWeight:700,marginBottom:8}}>Upgrade your membership</div>
          {upgradeError && (
            <div style={{fontSize:12,color:'#ef4444',background:'rgba(255,90,90,.1)',border:'1px solid rgba(255,90,90,.35)',borderRadius:8,padding:'8px 12px',marginBottom:10}}>{upgradeError}</div>
          )}
          <div style={{display:'grid',gridTemplateColumns:'repeat(auto-fill,minmax(180px,220px))',gap:10}}>
            {upgradeOptions.map((t:any) => (
              <div key={t.tier} className="card">
                <div style={{fontSize:14,fontWeight:800}}>{TIER_LABELS[t.tier] || t.tier}</div>
                <div style={{fontSize:18,fontWeight:800,color:'var(--nx-orange)',margin:'6px 0'}}>
                  {t.price_numeric !== null && t.price_numeric !== undefined ? t.price : 'TBD'}
                </div>
                <button
                  className="btn btn-sm btn-p"
                  style={{width:'100%'}}
                  disabled={upgrading === t.tier}
                  onClick={() => handleUpgrade(t)}
                >
                  {upgrading === t.tier ? 'Processing…' : (t.price_numeric !== null && t.price_numeric !== undefined ? `Upgrade to ${TIER_LABELS[t.tier] || t.tier}` : 'Contact us')}
                </button>
              </div>
            ))}
          </div>
        </div>
      )}

      <div style={{fontSize:11,color:'var(--nx-muted)',marginTop:10}}>
        Business Hub posting and full Learning Ground access are enforced automatically based on your tier — everything else above is informational for now.
      </div>
    </div>
  )
}