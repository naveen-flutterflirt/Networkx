'use client'
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome'
import { faBriefcase, faHandshake, faLink, faLocationDot, faTrophy, faUser, faCamera,
  faCircleCheck, faClock, faSquare, faStar, faPaperPlane } from '@fortawesome/free-solid-svg-icons'
import { useState, useEffect, useRef } from 'react'
import { getUser } from '@/lib/auth'
import { ProfileAPI, ConnectionsAPI, ReferralsAPI, GamificationAPI, TrustAPI, TestimonialsAPI } from '@/lib/api'
import { Loading, ApiError } from '@/components/shared/States'
import CompanyPicker from '@/components/ui/CompanyPicker'
import TagInput from '@/components/ui/TagInput'

// Real completeness — was a hardcoded "78%" for every account regardless
// of what was actually filled in, here and in the sidebar. Counts how
// many of the fields that actually exist on the backend are filled in.
const TRACKED_FIELDS = ['bio','profession','company','city','category','country','looking_for','can_help_with','linkedin','website']
function completeness(p: any) {
  const filled = TRACKED_FIELDS.filter(f => (p?.[f] || '').toString().trim().length > 0).length
  return Math.round((filled / TRACKED_FIELDS.length) * 100)
}

export default function ProfilePage() {
  const user = getUser()
  const [profile, setProfile] = useState<any>(null)
  const [form, setForm] = useState<any>(null)
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState('')
  const [saving, setSaving] = useState(false)
  const [uploadingAvatar, setUploadingAvatar] = useState(false)
  const [showShare, setShowShare] = useState(false)
  const [copied, setCopied] = useState(false)
  const [msg, setMsg] = useState('')
  const [stats, setStats] = useState<any>({connections:0, given:0})
  const [game, setGame] = useState<any>(null)
  const [trust, setTrust] = useState<any>(null)
  const [requestingVerify, setRequestingVerify] = useState(false)
  const [testimonials, setTestimonials] = useState<any[]>([])
  const [givenTestimonials, setGivenTestimonials] = useState<any[]>([])
  const [testimonialTab, setTestimonialTab] = useState<'received'|'given'>('received')
  const [sentRequests, setSentRequests] = useState<any[]>([])
  const [incomingRequests, setIncomingRequests] = useState<any[]>([])
  const [remindingId, setRemindingId] = useState<string | null>(null)
  const [writingFor, setWritingFor] = useState<any>(null)
  const [writeText, setWriteText] = useState('')
  const [writeRating, setWriteRating] = useState(5)
  const [submittingWrite, setSubmittingWrite] = useState(false)
  const [writeModalMsg, setWriteModalMsg] = useState('')
  const [showTestimonialRequest, setShowTestimonialRequest] = useState(false)
  const [myConnections, setMyConnections] = useState<any[]>([])
  const [loadingConnections, setLoadingConnections] = useState(false)
  const [requestedIds, setRequestedIds] = useState<string[]>([])

  const fetchAll = async () => {
    setLoading(true); setError('')
    try {
      const meId = user?.id
      const [p, connRes, refRes, gameRes, trustRes, testimonialsRes, sentRes, incomingRes, givenRes] = await Promise.all([
        ProfileAPI.get(),
        ConnectionsAPI.list().catch(()=>({counts:{connected:0}})),
        ReferralsAPI.stats().catch(()=>({given:0})),
        GamificationAPI.me().catch(()=>null),
        meId ? TrustAPI.get(meId).catch(()=>null) : Promise.resolve(null),
        TestimonialsAPI.mine().catch(()=>[]),
        TestimonialsAPI.sent().catch(()=>[]),
        TestimonialsAPI.requests().catch(()=>[]),
        TestimonialsAPI.given().catch(()=>[]),
      ])
      setProfile(p)
      setForm({
        bio: p.bio||'', profession: p.profession||'', company: p.company||'', company_id: p.company_id||'',
        city: p.city||'', category: p.category||'', country: p.country||'',
        looking_for: p.looking_for||'', can_help_with: p.can_help_with||[], open_to_referrals: p.open_to_referrals||false,
        linkedin: p.linkedin||'', website: p.website||'',
        twitter: p.twitter||'', instagram: p.instagram||'', facebook: p.facebook||'',
        username: p.username||'',
      })
      setStats({ connections: connRes.counts?.connected||0, given: refRes.given||0 })
      setGame(gameRes)
      setTrust(trustRes)
      setTestimonials(testimonialsRes || [])
      setSentRequests(sentRes || [])
      setIncomingRequests(incomingRes || [])
      setGivenTestimonials(givenRes || [])
    } catch (e: any) { setError(e.message) }
    finally { setLoading(false) }
  }

  const requestVerification = async () => {
    setRequestingVerify(true)
    try {
      await TrustAPI.requestVerification({})
      setTrust((t: any) => ({...t, verification_status: 'pending'}))
      setMsg('✅ Verification requested — HQ will review it')
    } catch (e: any) { setMsg('❌ ' + e.message) }
    finally { setRequestingVerify(false) }
  }
  useEffect(() => { fetchAll() }, [])

  const save = async () => {
    setSaving(true)
    try {
      await ProfileAPI.update(form)
      // Was merging `form` into local state and trusting it worked —
      // if the backend silently dropped a field, the UI still showed
      // "saved" until the next reload. Re-fetching the real saved state
      // from the server instead means what you see IS what persisted.
      const fresh = await ProfileAPI.get()
      setProfile(fresh)
      setForm({
        bio: fresh.bio||'', profession: fresh.profession||'', company: fresh.company||'', company_id: fresh.company_id||'',
        city: fresh.city||'', category: fresh.category||'', country: fresh.country||'',
        looking_for: fresh.looking_for||'', can_help_with: fresh.can_help_with||[], open_to_referrals: fresh.open_to_referrals||false,
        linkedin: fresh.linkedin||'', website: fresh.website||'',
        twitter: fresh.twitter||'', instagram: fresh.instagram||'', facebook: fresh.facebook||'',
        username: fresh.username||'',
      })
      setMsg('✅ Profile updated!')
    } catch (e: any) { setMsg('❌ ' + e.message) }
    finally { setSaving(false) }
  }

  // Real Firebase Storage upload — same working signed-URL pattern used
  // elsewhere (Deal Corner, Merch, Learning).
  //
  // Fix: the PUT to the signed URL was never checked for success — only a
  // network-level failure (offline, DNS, CORS) would throw. An HTTP error
  // response (403/404/etc, e.g. an expired signed URL) resolved normally,
  // so the code went on to save that broken URL to the profile and show
  // "✅ Photo updated!" even though nothing was actually stored — which is
  // exactly the "upload done but not visible" symptom. Now the PUT's
  // status is checked and a failed upload surfaces as an error instead of
  // a false success.
  const uploadAvatar = async (fileOrBlob: File | Blob, filename: string, contentType: string) => {
    setUploadingAvatar(true)
    try {
      const { upload_url, blob_path, error } = await ProfileAPI.getAvatarUploadUrl({ filename, content_type: contentType })
      if (error || !upload_url) throw new Error(error || 'Could not get an upload URL')
      const putRes = await fetch(upload_url, { method: 'PUT', headers: { 'Content-Type': contentType }, body: fileOrBlob })
      if (!putRes.ok) throw new Error(`Storage upload failed (${putRes.status})`)
      // Server saves blob_path (private object) and hands back a
      // freshly signed, short-lived view URL — nothing here is a public
      // URL, so this only works because we're authenticated.
      const { avatar_url } = await ProfileAPI.uploadAvatar({ blob_path })
      setProfile((prev: any) => ({...prev, avatar_url}))
      setMsg('✅ Photo updated!')
    } catch (e: any) { setMsg('❌ Upload failed: ' + e.message) }
    finally { setUploadingAvatar(false) }
  }

  const removeAvatar = async () => {
    setUploadingAvatar(true)
    try {
      await ProfileAPI.uploadAvatar({ blob_path: '' })
      setProfile((prev: any) => ({...prev, avatar_url: ''}))
      setMsg('✅ Photo removed')
    } catch (e: any) { setMsg('❌ ' + e.message) }
    finally { setUploadingAvatar(false) }
  }

  // "Adjust photo" — previously there was no way to reposition/zoom a
  // photo before it was saved; picking a file uploaded it immediately
  // as-is. Now file selection opens a crop step (zoom + drag-to-pan on a
  // square canvas) and only the cropped result is uploaded.
  const [pendingImage, setPendingImage] = useState<string | null>(null)
  const [cropZoom, setCropZoom] = useState(1)
  const [cropPos, setCropPos] = useState({x: 0, y: 0})
  const [pendingMeta, setPendingMeta] = useState<{name:string, type:string} | null>(null)
  const dragRef = useRef<{dragging:boolean, startX:number, startY:number, origX:number, origY:number}>({dragging:false, startX:0, startY:0, origX:0, origY:0})

  const onPickFile = (file: File) => {
    if (!file.type.startsWith('image/')) { setMsg('❌ Please choose an image file'); return }
    const reader = new FileReader()
    reader.onload = () => {
      setPendingImage(reader.result as string)
      setPendingMeta({name: file.name, type: file.type})
      setCropZoom(1); setCropPos({x:0,y:0})
    }
    reader.readAsDataURL(file)
  }

  const confirmCrop = async () => {
    if (!pendingImage || !pendingMeta) return
    const img = new Image()
    img.src = pendingImage
    await new Promise(res => { img.onload = res })
    const SIZE = 320
    const canvas = document.createElement('canvas')
    canvas.width = SIZE; canvas.height = SIZE
    const ctx = canvas.getContext('2d')!
    const scale = Math.max(SIZE / img.width, SIZE / img.height) * cropZoom
    const drawW = img.width * scale, drawH = img.height * scale
    const dx = (SIZE - drawW) / 2 + cropPos.x
    const dy = (SIZE - drawH) / 2 + cropPos.y
    ctx.drawImage(img, dx, dy, drawW, drawH)
    canvas.toBlob(async (blob) => {
      if (!blob) { setMsg('❌ Could not process image'); return }
      await uploadAvatar(blob, pendingMeta.name.replace(/\.\w+$/, '') + '.jpg', 'image/jpeg')
      setPendingImage(null); setPendingMeta(null)
    }, 'image/jpeg', 0.92)
  }

  const onDragStart = (e: React.MouseEvent) => {
    dragRef.current = {dragging:true, startX:e.clientX, startY:e.clientY, origX:cropPos.x, origY:cropPos.y}
  }
  const onDragMove = (e: React.MouseEvent) => {
    if (!dragRef.current.dragging) return
    const dx = e.clientX - dragRef.current.startX
    const dy = e.clientY - dragRef.current.startY
    setCropPos({x: dragRef.current.origX + dx, y: dragRef.current.origY + dy})
  }
  const onDragEnd = () => { dragRef.current.dragging = false }

  // Query param, not a path segment — this app is statically exported
  // (no SSR), so a dynamic /profile/[username] route can't resolve at
  // request time. /profile?u=<username> works fine as a static page.
  const openTestimonialRequest = async () => {
    setShowTestimonialRequest(true)
    setTestimonialModalMsg('')
    setLoadingConnections(true)
    try {
      const res = await ConnectionsAPI.list('accepted')
      setMyConnections(res.connected || [])
    } catch (e: any) { setMsg('❌ ' + e.message) }
    finally { setLoadingConnections(false) }
  }

  const [testimonialModalMsg, setTestimonialModalMsg] = useState('')
  const [shareModalMsg, setShareModalMsg] = useState('')
  const sendTestimonialRequest = async (authorId: string) => {
    try {
      await TestimonialsAPI.request(authorId)
      setRequestedIds(prev => [...prev, authorId])
      setTestimonialModalMsg('✅ Request sent!')
      setMsg('✅ Request sent!')
      TestimonialsAPI.sent().then(setSentRequests).catch(()=>{})
    } catch (e: any) { setTestimonialModalMsg('❌ ' + e.message); setMsg('❌ ' + e.message) }
  }

  const sendReminder = async (testimonialId: string) => {
    setRemindingId(testimonialId)
    try {
      await TestimonialsAPI.remind(testimonialId)
      setMsg('✅ Reminder sent!')
    } catch (e: any) { setMsg('❌ ' + e.message) }
    finally { setRemindingId(null) }
  }

  const openWriteModal = (req: any) => {
    setWritingFor(req)
    setWriteText('')
    setWriteRating(5)
    setWriteModalMsg('')
  }

  const submitTestimonial = async () => {
    if (!writingFor) return
    if (writeText.trim().length < 10) { setWriteModalMsg('❌ Please write at least 10 characters'); return }
    setSubmittingWrite(true)
    try {
      await TestimonialsAPI.submit(writingFor.id, { text: writeText.trim(), rating: writeRating })
      setIncomingRequests(prev => prev.filter(r => r.id !== writingFor.id))
      TestimonialsAPI.given().then(setGivenTestimonials).catch(()=>{})
      setMsg('✅ Testimonial sent!')
      setWritingFor(null)
    } catch (e: any) { setWriteModalMsg('❌ ' + e.message) }
    finally { setSubmittingWrite(false) }
  }

  const profileUrl = typeof window !== 'undefined' ? `${window.location.origin}/profile?u=${profile?.username || user?.id}` : ''
  const copyProfileUrl = () => {
    navigator.clipboard.writeText(profileUrl)
    setCopied(true)
    setTimeout(() => setCopied(false), 2000)
  }

  if (!user) return null
  if (loading) return <div className="page"><Loading label="Loading your profile…"/></div>
  if (error) return <div className="page"><ApiError message={error} onRetry={fetchAll}/></div>

  const pct = completeness(profile)

  return (
    <div className="page">
      {msg && (
        <div className="toast-in" style={{padding:'10px 14px',borderRadius:10,marginBottom:12,fontSize:13,
          background:msg.startsWith('✅')?'rgba(39,216,109,.1)':'rgba(255,90,90,.1)',
          color:msg.startsWith('✅')?'#16a34a':'#ef4444',
          border:`1px solid ${msg.startsWith('✅')?'rgba(39,216,109,.35)':'rgba(255,90,90,.35)'}`}}>
          {msg}<button style={{marginLeft:12,background:'none',border:'none',cursor:'pointer',color:'#9ca3af'}} onClick={()=>setMsg('')}>✕</button>
        </div>
      )}
      <div style={{display:'grid',gridTemplateColumns:'320px 1fr',gap:20}}>
        {/* Left panel — real data */}
        <div>
          <div className="card" style={{textAlign:'center',marginBottom:14}}>
            <div style={{position:'relative',width:80,height:80,margin:'0 auto 12px'}}>
              {profile.avatar_url ? (
                <img src={profile.avatar_url} alt={profile.name} style={{width:80,height:80,borderRadius:'50%',objectFit:'cover'}}/>
              ) : (
                <div className="av" style={{width:80,height:80,fontSize:28,background:'var(--nx-orange)'}}>{profile.name?.charAt(0)||'?'}</div>
              )}
              <label style={{position:'absolute',bottom:-2,right:-2,width:26,height:26,borderRadius:'50%',background:'var(--nx-panel2)',border:'2px solid var(--nx-panel)',display:'flex',alignItems:'center',justifyContent:'center',cursor:uploadingAvatar?'wait':'pointer',fontSize:12}}>
                {uploadingAvatar ? '…' : <FontAwesomeIcon icon={faCamera}/>}
                <input type="file" accept="image/*" disabled={uploadingAvatar} style={{display:'none'}} onChange={e=>{ if(e.target.files?.[0]) onPickFile(e.target.files[0]); e.target.value='' }}/>
              </label>
            </div>
            {profile.avatar_url && (
              <button onClick={removeAvatar} disabled={uploadingAvatar} style={{background:'none',border:'none',color:'#9ca3af',fontSize:11,cursor:'pointer',textDecoration:'underline',marginTop:-6,marginBottom:4}}>
                Remove photo
              </button>
            )}
            <div style={{fontSize:18,fontWeight:800,display:'flex',alignItems:'center',justifyContent:'center',gap:6}}>
              {profile.name}
              {trust?.verification_status === 'approved' && <span title="Verified by NetworkX HQ" style={{color:'#168fff',fontSize:15}}><FontAwesomeIcon icon={faCircleCheck}/></span>}
            </div>
            <div style={{fontSize:13,color:'#9ca3af'}}>{form.profession || 'Add your profession below'}</div>
            <div style={{fontSize:13,color:'#9ca3af'}}>{form.company || ''}</div>
            <div style={{fontSize:12,color:'#9ca3af',marginTop:4}}><FontAwesomeIcon icon={faLocationDot} className="mr-1.5"/>{form.city || 'City not set'}</div>
            {trust && <div style={{fontSize:11,color:'#6b7280',marginTop:4}}><FontAwesomeIcon icon={faClock} className="mr-1"/>{trust.tenure_label}</div>}
            <div style={{display:'grid',gridTemplateColumns:'1fr 1fr',gap:8,margin:'14px 0',background:'rgba(255,255,255,.04)',borderRadius:10,padding:10}}>
              <div><div style={{fontWeight:800,fontSize:16}}>{stats.connections}</div><div style={{fontSize:10,color:'#9ca3af'}}>Connections</div></div>
              <div><div style={{fontWeight:800,fontSize:16}}>{stats.given}</div><div style={{fontSize:10,color:'#9ca3af'}}>Referrals Given</div></div>
            </div>
            {trust && trust.verification_status !== 'approved' && (
              <button className="btn btn-g btn-sm" style={{width:'100%',marginBottom:8}} disabled={trust.verification_status==='pending' || requestingVerify} onClick={requestVerification}>
                {trust.verification_status==='pending' ? <><FontAwesomeIcon icon={faClock} className="mr-1.5"/>Verification Pending</> : <><FontAwesomeIcon icon={faCircleCheck} className="mr-1.5"/>Request Verification</>}
              </button>
            )}
            <button className="btn btn-g btn-sm" style={{width:'100%'}} onClick={()=>{setShowShare(true); setShareModalMsg('')}}><FontAwesomeIcon icon={faLink} className="mr-1.5"/>Share Profile</button>
          </div>


          <div className="card">
            <div style={{fontWeight:700,fontSize:13,marginBottom:10}}><FontAwesomeIcon icon={faTrophy} className="mr-1.5"/>Profile Completion</div>
            <div className="prog" style={{marginBottom:6}}><div className="prog-fill" style={{width:`${pct}%`}}/></div>
            <div style={{fontSize:12,color:'#9ca3af',marginBottom:10}}>{pct}% complete — this is real, calculated from what you've actually filled in below</div>
            {TRACKED_FIELDS.map(f=>(
              <div key={f} style={{display:'flex',alignItems:'center',gap:8,marginBottom:6,fontSize:12}}>
                <span>{(form[f]||'').toString().trim() ? <FontAwesomeIcon icon={faCircleCheck} className="text-green"/> : <FontAwesomeIcon icon={faSquare} className="text-muted"/>}</span>
                <span style={{color:(form[f]||'').toString().trim() ? '#cbd5e1' : '#9ca3af',textTransform:'capitalize'}}>{f.replace(/_/g,' ')}</span>
              </div>
            ))}
          </div>

          {game && (
            <div className="card" style={{marginTop:14}}>
              <div style={{display:'flex',justifyContent:'space-between',alignItems:'center',marginBottom:4}}>
                <div style={{fontWeight:700,fontSize:13}}>{game.level_name}</div>
                <div style={{fontSize:11,color:'#9ca3af'}}>{game.points} pts</div>
              </div>
              {game.next_level && (
                <>
                  <div className="prog" style={{marginBottom:6}}>
                    <div className="prog-fill" style={{width:`${Math.min(100, (game.points/(game.points+game.points_to_next))*100)}%`,background:'#6366f1'}}/>
                  </div>
                  <div style={{fontSize:11,color:'#9ca3af',marginBottom:14}}>{game.points_to_next} pts to {game.next_level}</div>
                </>
              )}
              <div style={{fontSize:12,fontWeight:700,color:'#9ca3af',marginBottom:10}}>BADGES</div>
              <div style={{display:'grid',gridTemplateColumns:'repeat(4,1fr)',gap:10}}>
                {game.badges.map((b: any) => (
                  <div key={b.id} title={b.earned ? b.description : `${b.description}${b.progress ? ` (${b.progress.current}/${b.progress.target})` : ''}`}
                    style={{textAlign:'center',opacity:b.earned?1:.35}}>
                    <div style={{fontSize:28,filter:b.earned?'none':'grayscale(1)'}}>{b.icon}</div>
                    <div style={{fontSize:9,color:b.earned?'#cbd5e1':'#6b7280',marginTop:2,overflow:'hidden',textOverflow:'ellipsis',whiteSpace:'nowrap'}}>{b.name}</div>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>

        {/* Right — real, editable fields, saved via the same ProfileAPI Settings uses */}
        <div style={{display:'flex',flexDirection:'column',gap:14}}>
          <div className="card">
            <div style={{fontWeight:700,fontSize:14,marginBottom:12}}><FontAwesomeIcon icon={faUser} className="mr-1.5"/>Bio</div>
            <textarea rows={4} value={form.bio} onChange={e=>setForm({...form,bio:e.target.value})}
              placeholder="Tell other members what you do and what you're looking for…" style={{fontSize:13,lineHeight:1.6}}/>
          </div>

          <div className="card">
            <div style={{fontWeight:700,fontSize:14,marginBottom:12}}><FontAwesomeIcon icon={faBriefcase} className="mr-1.5"/>Professional Info</div>
            <div className="form-grid">
              <div className="fg"><label>Profession</label><input value={form.profession} onChange={e=>setForm({...form,profession:e.target.value})}/></div>
              <CompanyPicker
                label="Company" value={form.company_id} currentName={form.company}
                onChange={(id, company) => setForm({...form, company_id: id, company: company?.name || form.company})}
              />
              <div className="fg"><label>City</label><input value={form.city} onChange={e=>setForm({...form,city:e.target.value})}/></div>
              <div className="fg"><label>Country</label><input value={form.country} onChange={e=>setForm({...form,country:e.target.value})}/></div>
              <div className="fg"><label>Business Category</label><input value={form.category} onChange={e=>setForm({...form,category:e.target.value})} placeholder="IT Services, Finance, Real Estate…"/></div>
              <div className="fg"><label>LinkedIn</label><input value={form.linkedin} onChange={e=>setForm({...form,linkedin:e.target.value})} placeholder="https://linkedin.com/in/…"/></div>
              <div className="fg"><label>Website</label><input value={form.website} onChange={e=>setForm({...form,website:e.target.value})} placeholder="https://…"/></div>
              <div className="fg"><label>Twitter / X</label><input value={form.twitter} onChange={e=>setForm({...form,twitter:e.target.value})} placeholder="https://x.com/…"/></div>
              <div className="fg"><label>Instagram</label><input value={form.instagram} onChange={e=>setForm({...form,instagram:e.target.value})} placeholder="https://instagram.com/…"/></div>
              <div className="fg"><label>Facebook</label><input value={form.facebook} onChange={e=>setForm({...form,facebook:e.target.value})} placeholder="https://facebook.com/…"/></div>
            </div>
          </div>

          <div className="card">
            <div style={{fontWeight:700,fontSize:14,marginBottom:12}}><FontAwesomeIcon icon={faHandshake} className="mr-1.5"/>What are you looking for?</div>
            <p style={{fontSize:11,color:'#9ca3af',marginBottom:10}}>This is exactly what shows up on your Discover card and what other members search for to find you.</p>
            <textarea rows={3} value={form.looking_for} onChange={e=>setForm({...form,looking_for:e.target.value})}
              placeholder="e.g. Introductions to procurement managers in South India, a reliable logistics partner…"/>

            <div style={{marginTop:14}}>
              <TagInput
                label="Can Help With"
                field="can_help_with"
                value={form.can_help_with}
                onChange={(tags) => setForm({...form, can_help_with: tags})}
                placeholder="e.g. GST filing, warehouse leasing, B2B sales…"
              />
              <p style={{fontSize:11,color:'#9ca3af',marginTop:6}}>Structured tags — start typing to reuse a tag other members already use, or add your own.</p>
            </div>

            <label style={{display:'flex',alignItems:'center',gap:8,marginTop:14,marginBottom:0}}>
              <input type="checkbox" checked={form.open_to_referrals} onChange={e=>setForm({...form,open_to_referrals:e.target.checked})} style={{width:'auto'}}/>
              Open to Referrals — show this badge on my Discover card
            </label>
          </div>

          <button className="btn btn-p" onClick={save} disabled={saving}>{saving?'Saving…':'Save Profile'}</button>
        </div>
      </div>

      {/* Testimonials — was completely missing before; no backend, no UI */}
      <div className="card" style={{marginTop:14}}>
        <div style={{display:'flex',justifyContent:'space-between',alignItems:'center',marginBottom:14}}>
          <div style={{fontWeight:700,fontSize:14}}><FontAwesomeIcon icon={faStar} className="mr-1.5" style={{color:'#f59e0b'}}/>Testimonials</div>
          <button className="btn btn-g btn-sm" onClick={openTestimonialRequest}>Request</button>
        </div>

        <div style={{display:'flex',gap:4,marginBottom:14,borderBottom:'1px solid rgba(255,255,255,.08)'}}>
          <button onClick={()=>setTestimonialTab('received')}
            style={{background:'none',border:'none',cursor:'pointer',padding:'8px 4px',fontSize:12,fontWeight:600,
              color:testimonialTab==='received'?'#fff':'#6b7280',
              borderBottom:testimonialTab==='received'?'2px solid var(--nx-orange)':'2px solid transparent'}}>
            Received {testimonials.length>0 && `(${testimonials.length})`}
          </button>
          <button onClick={()=>setTestimonialTab('given')}
            style={{background:'none',border:'none',cursor:'pointer',padding:'8px 12px',fontSize:12,fontWeight:600,
              color:testimonialTab==='given'?'#fff':'#6b7280',
              borderBottom:testimonialTab==='given'?'2px solid var(--nx-orange)':'2px solid transparent'}}>
            Given {givenTestimonials.length>0 && `(${givenTestimonials.length})`}
            {incomingRequests.length>0 && <span style={{marginLeft:6,background:'#3b82f6',color:'#fff',borderRadius:10,padding:'1px 6px',fontSize:10}}>{incomingRequests.length}</span>}
          </button>
        </div>

        {testimonialTab === 'received' ? (
          <>
            {sentRequests.length > 0 && (
              <div style={{display:'flex',flexDirection:'column',gap:8,marginBottom:14}}>
                {sentRequests.map(r => (
                  <div key={r.id} style={{display:'flex',justifyContent:'space-between',alignItems:'center',background:'rgba(245,158,11,.06)',border:'1px solid rgba(245,158,11,.25)',borderRadius:8,padding:'8px 12px'}}>
                    <span style={{fontSize:12,color:'#f59e0b'}}>⏳ Waiting on {r.author_name}</span>
                    <button className="btn btn-g btn-sm" disabled={remindingId===r.id} onClick={()=>sendReminder(r.id)}>
                      {remindingId===r.id ? '…' : 'Send Reminder'}
                    </button>
                  </div>
                ))}
              </div>
            )}
            {testimonials.length === 0 ? (
              <p style={{fontSize:12,color:'#9ca3af'}}>No testimonials yet — ask a connection to write one for you.</p>
            ) : (
              <div style={{display:'flex',flexDirection:'column',gap:10}}>
                {testimonials.map(t => (
                  <div key={t.id} style={{background:'rgba(255,255,255,.03)',borderRadius:10,padding:'12px 14px'}}>
                    <div style={{display:'flex',justifyContent:'space-between',alignItems:'flex-start',marginBottom:6}}>
                      <div>
                        <div style={{fontWeight:700,fontSize:13}}>{t.author_name}</div>
                        <div style={{fontSize:11,color:'#9ca3af'}}>
                          {[t.author_profession, t.author_city].filter(Boolean).join(', ')}
                        </div>
                      </div>
                      <div style={{color:'#f59e0b',fontSize:12,whiteSpace:'nowrap'}}>
                        {'★'.repeat(t.rating || 0)}{'☆'.repeat(5 - (t.rating || 0))}
                      </div>
                    </div>
                    <p style={{fontSize:12,color:'#cbd5e1',fontStyle:'italic',lineHeight:1.6}}>"{t.text}"</p>
                  </div>
                ))}
              </div>
            )}
          </>
        ) : (
          <>
            {incomingRequests.length > 0 && (
              <div style={{display:'flex',flexDirection:'column',gap:8,marginBottom:14}}>
                {incomingRequests.map(r => (
                  <div key={r.id} style={{display:'flex',justifyContent:'space-between',alignItems:'center',background:'rgba(59,130,246,.06)',border:'1px solid rgba(59,130,246,.25)',borderRadius:8,padding:'8px 12px'}}>
                    <span style={{fontSize:12,color:'#60a5fa'}}>✍️ {r.subject_name} asked you to write a testimonial</span>
                    <button className="btn btn-p btn-sm" onClick={()=>openWriteModal(r)}>Write</button>
                  </div>
                ))}
              </div>
            )}
            {givenTestimonials.length === 0 ? (
              <p style={{fontSize:12,color:'#9ca3af'}}>You haven't written any testimonials yet.</p>
            ) : (
              <div style={{display:'flex',flexDirection:'column',gap:10}}>
                {givenTestimonials.map(t => (
                  <div key={t.id} style={{background:'rgba(255,255,255,.03)',borderRadius:10,padding:'12px 14px'}}>
                    <div style={{display:'flex',justifyContent:'space-between',alignItems:'flex-start',marginBottom:6}}>
                      <div style={{fontWeight:700,fontSize:13}}>For {t.subject_name}</div>
                      <div style={{color:'#f59e0b',fontSize:12,whiteSpace:'nowrap'}}>
                        {'★'.repeat(t.rating || 0)}{'☆'.repeat(5 - (t.rating || 0))}
                      </div>
                    </div>
                    <p style={{fontSize:12,color:'#cbd5e1',fontStyle:'italic',lineHeight:1.6}}>"{t.text}"</p>
                  </div>
                ))}
              </div>
            )}
          </>
        )}
      </div>

      {writingFor && (
        <div className="overlay" onClick={e=>e.target===e.currentTarget && !submittingWrite && setWritingFor(null)}>
          <div className="modal">
            <h3 style={{fontSize:16,fontWeight:700,marginBottom:4}}>Write a Testimonial for {writingFor.subject_name}</h3>
            <p style={{fontSize:12,color:'#9ca3af',marginBottom:14}}>This will be shown publicly on their profile.</p>
            <label style={{fontSize:11,color:'#9ca3af'}}>Rating</label>
            <div style={{display:'flex',gap:4,marginBottom:12,fontSize:22}}>
              {[1,2,3,4,5].map(n => (
                <span key={n} style={{cursor:'pointer',color:n<=writeRating?'#f59e0b':'#374151'}} onClick={()=>setWriteRating(n)}>★</span>
              ))}
            </div>
            <label style={{fontSize:11,color:'#9ca3af'}}>Testimonial</label>
            <textarea value={writeText} onChange={e=>setWriteText(e.target.value)} rows={4}
              placeholder={`What was it like working with ${writingFor.subject_name}?`}
              style={{width:'100%',fontSize:13,marginBottom:12,resize:'vertical'}}/>
            {writeModalMsg && (
              <div style={{padding:'8px 12px',borderRadius:8,marginBottom:12,fontSize:12,
                background:writeModalMsg.startsWith('✅')?'rgba(39,216,109,.1)':'rgba(255,90,90,.1)',
                color:writeModalMsg.startsWith('✅')?'#16a34a':'#ef4444',
                border:`1px solid ${writeModalMsg.startsWith('✅')?'rgba(39,216,109,.35)':'rgba(255,90,90,.35)'}`}}>
                {writeModalMsg}
              </div>
            )}
            <div style={{display:'flex',gap:8}}>
              <button className="btn btn-g" style={{flex:1}} disabled={submittingWrite} onClick={()=>setWritingFor(null)}>Cancel</button>
              <button className="btn btn-p" style={{flex:1}} disabled={submittingWrite} onClick={submitTestimonial}>
                {submittingWrite ? 'Sending…' : 'Submit'}
              </button>
            </div>
          </div>
        </div>
      )}

      {showTestimonialRequest && (
        <div className="overlay" onClick={e=>e.target===e.currentTarget&&setShowTestimonialRequest(false)}>
          <div className="modal">
            <h3 style={{fontSize:16,fontWeight:700,marginBottom:4}}>Request a Testimonial</h3>
            <p style={{fontSize:12,color:'#9ca3af',marginBottom:14}}>Ask one of your connections to write a testimonial for your profile.</p>
            {testimonialModalMsg && (
              <div style={{padding:'8px 12px',borderRadius:8,marginBottom:12,fontSize:12,
                background:testimonialModalMsg.startsWith('✅')?'rgba(39,216,109,.1)':'rgba(255,90,90,.1)',
                color:testimonialModalMsg.startsWith('✅')?'#16a34a':'#ef4444',
                border:`1px solid ${testimonialModalMsg.startsWith('✅')?'rgba(39,216,109,.35)':'rgba(255,90,90,.35)'}`}}>
                {testimonialModalMsg}
              </div>
            )}
            {loadingConnections ? (
              <p style={{fontSize:12,color:'#9ca3af'}}>Loading your connections…</p>
            ) : myConnections.length === 0 ? (
              <p style={{fontSize:12,color:'#9ca3af'}}>You don't have any connections yet — connect with other members first.</p>
            ) : (
              <div style={{display:'flex',flexDirection:'column',gap:8,maxHeight:280,overflowY:'auto',marginBottom:14}}>
                {myConnections.map((c:any) => (
                  <div key={c.other_user_id} style={{display:'flex',justifyContent:'space-between',alignItems:'center',background:'rgba(255,255,255,.03)',borderRadius:8,padding:'8px 12px'}}>
                    <div>
                      <div style={{fontSize:13,fontWeight:600}}>{c.user?.name}</div>
                      <div style={{fontSize:11,color:'#9ca3af'}}>{c.user?.city}</div>
                    </div>
                    <button className="btn btn-p btn-sm" disabled={requestedIds.includes(c.other_user_id)}
                      onClick={()=>sendTestimonialRequest(c.other_user_id)}>
                      {requestedIds.includes(c.other_user_id) ? <><FontAwesomeIcon icon={faCircleCheck} className="mr-1"/>Sent</> : <><FontAwesomeIcon icon={faPaperPlane} className="mr-1"/>Ask</>}
                    </button>
                  </div>
                ))}
              </div>
            )}
            <button className="btn btn-g" style={{width:'100%'}} onClick={()=>setShowTestimonialRequest(false)}>Close</button>
          </div>
        </div>
      )}

      {pendingImage && (
        <div className="overlay" onClick={e=>e.target===e.currentTarget && !uploadingAvatar && setPendingImage(null)}>
          <div className="modal">
            <h3 style={{fontSize:16,fontWeight:700,marginBottom:4}}>Adjust Photo</h3>
            <p style={{fontSize:12,color:'#9ca3af',marginBottom:14}}>Drag to reposition, use the slider to zoom.</p>
            <div
              onMouseDown={onDragStart} onMouseMove={onDragMove} onMouseUp={onDragEnd} onMouseLeave={onDragEnd}
              style={{width:220,height:220,borderRadius:'50%',overflow:'hidden',margin:'0 auto 14px',position:'relative',cursor:'grab',background:'#111',border:'2px solid var(--nx-panel2)'}}>
              <img src={pendingImage} draggable={false} alt="Preview"
                style={{position:'absolute',top:'50%',left:'50%',
                  transform:`translate(calc(-50% + ${cropPos.x}px), calc(-50% + ${cropPos.y}px)) scale(${cropZoom})`,
                  maxWidth:'none',width:220,pointerEvents:'none'}}/>
            </div>
            <label style={{fontSize:12,color:'#9ca3af'}}>Zoom</label>
            <input type="range" min={1} max={3} step={0.05} value={cropZoom} onChange={e=>setCropZoom(parseFloat(e.target.value))} style={{width:'100%',marginBottom:14}}/>
            <div style={{display:'flex',gap:8}}>
              <button className="btn btn-g" style={{flex:1}} disabled={uploadingAvatar} onClick={()=>setPendingImage(null)}>Cancel</button>
              <button className="btn btn-p" style={{flex:1}} disabled={uploadingAvatar} onClick={confirmCrop}>{uploadingAvatar?'Uploading…':'Save Photo'}</button>
            </div>
          </div>
        </div>
      )}

      {showShare && (
        <div className="overlay" onClick={e=>e.target===e.currentTarget&&setShowShare(false)}>
          <div className="modal">
            <h3 style={{fontSize:16,fontWeight:700,marginBottom:4}}>Share Your Profile</h3>
            <p style={{fontSize:12,color:'#9ca3af',marginBottom:14}}>Anyone with this link can view your public profile — no login required. Shows your name, bio, and what you're looking for, not your email or phone.</p>
            <div style={{display:'flex',gap:8,marginBottom:10}}>
              <input readOnly value={profileUrl} style={{fontSize:12}}/>
              <button className="btn btn-p btn-sm" onClick={copyProfileUrl}>{copied ? <><FontAwesomeIcon icon={faCircleCheck} className="mr-1"/>Copied</> : 'Copy'}</button>
            </div>
            <label style={{fontSize:11,color:'#9ca3af'}}>Customize your link</label>
            <div style={{display:'flex',gap:8,alignItems:'center',marginBottom:14}}>
              <span style={{fontSize:12,color:'#6b7280'}}>{typeof window!=='undefined'?window.location.origin:''}/profile?u=</span>
              <input value={form?.username||''} onChange={e=>setForm({...form,username:e.target.value.toLowerCase().replace(/[^a-z0-9-]/g,'')})} style={{fontSize:12,flex:1}} placeholder={profile?.username}/>
            </div>
            {shareModalMsg && (
              <div style={{padding:'8px 12px',borderRadius:8,marginBottom:12,fontSize:12,
                background:shareModalMsg.startsWith('✅')?'rgba(39,216,109,.1)':'rgba(255,90,90,.1)',
                color:shareModalMsg.startsWith('✅')?'#16a34a':'#ef4444',
                border:`1px solid ${shareModalMsg.startsWith('✅')?'rgba(39,216,109,.35)':'rgba(255,90,90,.35)'}`}}>
                {shareModalMsg}
              </div>
            )}
            <div style={{display:'flex',gap:8}}>
              <button className="btn btn-g" style={{flex:1}} onClick={()=>setShowShare(false)}>Close</button>
              {form?.username && form.username !== profile?.username && (
                <button className="btn btn-p" style={{flex:1}} onClick={async ()=>{
                  try { await ProfileAPI.update({username: form.username}); await fetchAll(); setShareModalMsg('✅ Link updated!'); setMsg('✅ Link updated!') }
                  catch(e:any){ setShareModalMsg('❌ ' + e.message); setMsg('❌ ' + e.message) }
                }}>Save Link</button>
              )}
            </div>
          </div>
        </div>
      )}
    </div>
  )
}