'use client'
import { useState, useEffect, useRef } from 'react'
import { MessagesAPI } from '@/lib/api'
import { TokenStore } from '@/lib/api'
import UserSearchPicker from '@/components/ui/UserSearchPicker'
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome'
import { faComment, faArrowRight } from '@fortawesome/free-solid-svg-icons'

export default function MessagesPage() {
  const [convos,    setConvos]    = useState<any[]>([])
  const [selected,  setSelected]  = useState<any|null>(null)
  const [messages,  setMessages]  = useState<any[]>([])
  const [newMsg,    setNewMsg]    = useState('')
  const [loading,   setLoading]   = useState(true)
  const [msgLoading,setMsgLoading]= useState(false)
  const [sending,   setSending]   = useState(false)
  const [error,     setError]     = useState('')
  const [newConvo,  setNewConvo]  = useState(false)
  const [recipientId, setRecipientId] = useState('')
  const [recipientPreset, setRecipientPreset] = useState<{id:string,name:string}|null>(null)
  const [firstMsg,  setFirstMsg]  = useState('')
  const bottomRef = useRef<HTMLDivElement>(null)
  const me = TokenStore.getUser()

  useEffect(() => {
    fetchConvos()
  }, [])

  // Deep link from "Message" buttons elsewhere in the app —
  // /dashboard/messages?to=<user_id>&name=<name> — previously every one of
  // those buttons just navigated here with no context, landing on the
  // generic inbox instead of that person's chat.
  useEffect(() => {
    const params = new URLSearchParams(window.location.search)
    const to = params.get('to')
    const name = params.get('name') || ''
    if (!to || loading) return

    const existing = convos.find((c:any) => (c.participants||[]).includes(to))
    if (existing) {
      openConvo(existing)
    } else {
      setRecipientId(to)
      setRecipientPreset({ id: to, name })
      setNewConvo(true)
    }
    // Clean the URL so re-fetching/back-nav doesn't re-trigger this
    window.history.replaceState({}, '', '/dashboard/messages')
  }, [loading])

  useEffect(() => {
    bottomRef.current?.scrollIntoView({ behavior: 'smooth' })
  }, [messages])

  const fetchConvos = async () => {
    setLoading(true); setError('')
    try {
      const res = await MessagesAPI.conversations()
      setConvos(res.items || res)
    } catch (e: any) { setError(e.message) }
    finally { setLoading(false) }
  }

  const openConvo = async (conv: any) => {
    setSelected(conv); setMsgLoading(true)
    try {
      const res = await MessagesAPI.get(conv.id)
      const msgs = (res.items || res).reverse()
      setMessages(msgs)
      await MessagesAPI.markRead(conv.id)
    } catch (e: any) { setError(e.message) }
    finally { setMsgLoading(false) }
  }

  // Real fix for "messages from the other person don't show up unless I
  // reopen the chat" — there was no polling at all before. Refetches the
  // open conversation every 5s while it's open, and the conversation list
  // every 15s so previews/unread state stay current too.
  useEffect(() => {
    if (!selected) return
    const poll = setInterval(async () => {
      try {
        const res = await MessagesAPI.get(selected.id)
        const msgs = (res.items || res).reverse()
        // Only replace (and let the scroll-to-bottom effect below fire)
        // if something actually changed — otherwise every 5s poll tick
        // would yank the view back to the bottom even if the person had
        // scrolled up to read earlier messages.
        setMessages(prev => {
          const changed = msgs.length !== prev.length || msgs[msgs.length-1]?.id !== prev[prev.length-1]?.id
          if (changed) MessagesAPI.markRead(selected.id).catch(()=>{})
          return changed ? msgs : prev
        })
      } catch { /* silent — don't disrupt an open chat over a transient poll failure */ }
    }, 5000)
    return () => clearInterval(poll)
  }, [selected?.id])

  useEffect(() => {
    const poll = setInterval(() => { fetchConvos() }, 15000)
    return () => clearInterval(poll)
  }, [])

  const sendMessage = async () => {
    if (!newMsg.trim() || !selected) return
    setSending(true)
    try {
      const msg = await MessagesAPI.send(selected.id, { text: newMsg.trim() })
      setMessages(prev => [...prev, msg])
      setNewMsg('')
    } catch (e: any) { setError(e.message) }
    finally { setSending(false) }
  }

  const startConvo = async () => {
    if (!recipientId.trim() || !firstMsg.trim()) return
    setSending(true)
    try {
      const conv = await MessagesAPI.start({ recipient_id: recipientId.trim(), message: firstMsg.trim() })
      setConvos(prev => [conv, ...prev])
      setNewConvo(false); setRecipientId(''); setRecipientPreset(null); setFirstMsg('')
      openConvo(conv)
    } catch (e: any) { setError(e.message) }
    finally { setSending(false) }
  }

  const otherParticipant = (conv: any) => {
    return conv?.user?.name || 'Unknown Member'
  }

  return (
    <div className="page" style={{padding:0,height:'calc(100vh - 60px)',display:'flex',overflow:'hidden'}}>

      {/* Left — conversation list */}
      <div className="card" style={{padding:0,borderRadius:0,width:300,flexShrink:0,borderRight:'1px solid var(--nx-line)',display:'flex',flexDirection:'column',height:'100%'}}>
        <div style={{padding:'16px',borderBottom:'1px solid var(--nx-line)',display:'flex',justifyContent:'space-between',alignItems:'center'}}>
          <h2 style={{fontSize:16,fontWeight:800,margin:0}}>Messages</h2>
          <button className="btn btn-p btn-sm" onClick={() => { setRecipientId(''); setRecipientPreset(null); setNewConvo(true) }}>+ New</button>
        </div>
        <div style={{flex:1,overflowY:'auto'}}>
          {loading
            ? [...Array(4)].map((_,i) => (
              <div key={i} style={{padding:'12px 16px',display:'flex',gap:10,borderBottom:'1px solid var(--nx-line)'}}>
                <div style={{width:36,height:36,borderRadius:'50%',background:'rgba(255,255,255,.06)',flexShrink:0}}/>
                <div style={{flex:1}}>
                  <div style={{height:12,background:'rgba(255,255,255,.06)',borderRadius:4,width:'60%',marginBottom:6}}/>
                  <div style={{height:10,background:'rgba(255,255,255,.04)',borderRadius:4,width:'80%'}}/>
                </div>
              </div>
            ))
            : convos.length === 0
            ? <div style={{padding:24,textAlign:'center',color:'#9ca3af',fontSize:13}}>No conversations yet</div>
            : convos.map(conv => (
              <div key={conv.id} onClick={() => openConvo(conv)}
                style={{padding:'12px 16px',display:'flex',gap:10,cursor:'pointer',borderBottom:'1px solid var(--nx-line)',
                  background: selected?.id === conv.id ? 'rgba(255,75,10,.1)' : 'var(--nx-panel)',
                  transition:'background .1s'}}>
                <div style={{width:36,height:36,borderRadius:'50%',background:'#6366f1',display:'flex',alignItems:'center',justifyContent:'center',color:'#fff',fontSize:12,fontWeight:700,flexShrink:0}}>
                  {(conv.user?.name || '?').charAt(0).toUpperCase()}
                </div>
                <div style={{flex:1,minWidth:0}}>
                  <div style={{fontSize:13,fontWeight:600,overflow:'hidden',textOverflow:'ellipsis',whiteSpace:'nowrap'}}>{otherParticipant(conv)}</div>
                  <div style={{fontSize:11,color:'#9ca3af',overflow:'hidden',textOverflow:'ellipsis',whiteSpace:'nowrap'}}>{conv.last_message || '...'}</div>
                </div>
              </div>
            ))
          }
        </div>
      </div>

      {/* Right — message thread */}
      <div style={{flex:1,display:'flex',flexDirection:'column',height:'100%'}}>
        {!selected
          ? <div style={{flex:1,display:'flex',alignItems:'center',justifyContent:'center',flexDirection:'column',color:'#9ca3af'}}>
              <div style={{fontSize:40,marginBottom:12}}><FontAwesomeIcon icon={faComment}/></div>
              <div style={{fontWeight:600,marginBottom:4}}>Select a conversation</div>
              <div style={{fontSize:13}}>or start a new one</div>
            </div>
          : <>
              {/* Header */}
              <div style={{padding:'12px 16px',borderBottom:'1px solid var(--nx-line)',display:'flex',alignItems:'center',gap:10}}>
                <div style={{width:36,height:36,borderRadius:'50%',background:'#6366f1',display:'flex',alignItems:'center',justifyContent:'center',color:'#fff',fontSize:12,fontWeight:700}}>
                  {otherParticipant(selected).charAt(0).toUpperCase()}
                </div>
                <div style={{fontWeight:600,fontSize:14}}>{otherParticipant(selected)}</div>
              </div>

              {/* Messages */}
              <div style={{flex:1,overflowY:'auto',padding:16,display:'flex',flexDirection:'column',gap:8}}>
                {msgLoading
                  ? <div style={{textAlign:'center',color:'#9ca3af',padding:24}}>Loading...</div>
                  : messages.map((msg, i) => {
                    const isMe = msg.sender_id === me?.id
                    return (
                      <div key={i} style={{display:'flex',justifyContent:isMe?'flex-end':'flex-start'}}>
                        <div style={{maxWidth:'70%',padding:'8px 12px',borderRadius:isMe?'18px 18px 4px 18px':'18px 18px 18px 4px',
                          background:isMe?'var(--nx-orange)':'var(--nx-line)',color:isMe?'#fff':'var(--nx-ink)',fontSize:13,lineHeight:1.5}}>
                          <div>{msg.text}</div>
                          <div style={{fontSize:10,opacity:.7,marginTop:3,textAlign:isMe?'right':'left'}}>
                            {msg.sent_at ? new Date(msg.sent_at).toLocaleTimeString([], {hour:'2-digit',minute:'2-digit'}) : ''}
                          </div>
                        </div>
                      </div>
                    )
                  })
                }
                <div ref={bottomRef}/>
              </div>

              {/* Input */}
              <div style={{padding:'12px 16px',borderTop:'1px solid var(--nx-line)',display:'flex',gap:8}}>
                <input value={newMsg} onChange={e => setNewMsg(e.target.value)}
                  onKeyDown={e => e.key === 'Enter' && !e.shiftKey && sendMessage()}
                  placeholder="Type a message..."
                  style={{flex:1,padding:'10px 14px',borderRadius:24,border:'1px solid var(--nx-line)',outline:'none',fontSize:13}}/>
                <button className="btn btn-p" onClick={sendMessage} disabled={sending || !newMsg.trim()}
                  style={{borderRadius:24,padding:'10px 20px'}}>
                  {sending ? '…' : <FontAwesomeIcon icon={faArrowRight}/>}
                </button>
              </div>
            </>
        }
      </div>

      {/* New Conversation Modal */}
      {newConvo && (
        <div className="overlay" onClick={e => e.target === e.currentTarget && (setNewConvo(false), setRecipientPreset(null))}>
          <div className="modal">
            <h3 style={{fontSize:16,fontWeight:700,marginBottom:14}}>New Conversation</h3>
            <div className="fg" style={{marginBottom:10}}>
              <UserSearchPicker
                label="Recipient"
                required
                placeholder="Search member by name, email or city…"
                value={recipientId}
                initialUser={recipientPreset}
                onChange={(id, user) => { setRecipientId(id); setRecipientPreset(user ? {id, name:user.name} : null) }}
              />
            </div>
            <div className="fg" style={{marginBottom:14}}>
              <label>First Message</label>
              <input value={firstMsg} onChange={e => setFirstMsg(e.target.value)} placeholder="Type your message..." autoFocus={!!recipientPreset}/>
            </div>
            {error && <div style={{color:'#ef4444',fontSize:13,marginBottom:10}}>{error}</div>}
            <div style={{display:'flex',gap:8}}>
              <button className="btn btn-p" style={{flex:1}} onClick={startConvo} disabled={sending || !recipientId || !firstMsg}>
                {sending ? 'Starting…' : 'Start Conversation'}
              </button>
              <button className="btn btn-g" style={{flex:1}} onClick={() => { setNewConvo(false); setRecipientPreset(null) }}>Cancel</button>
            </div>
          </div>
        </div>
      )}
    </div>
  )
}
