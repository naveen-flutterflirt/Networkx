'use client'
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome'
import { faComment, faBullseye, faHandshake, faSackDollar } from '@fortawesome/free-solid-svg-icons'
import { useState, useEffect } from 'react'
import { MatchingAPI } from '@/lib/api'
import { Loading, ApiError, Empty } from '@/components/shared/States'

const INTENTS = [
  {id:'general',   l:'Member Matching', ic:faBullseye, desc:'Find members who match what you need or offer'},
  {id:'cofounder', l:'Co-founder Match', ic:faHandshake, desc:'Find a co-founder for your next venture'},
  {id:'investor',  l:'Investor Reachout', ic:faSackDollar, desc:'Connect with members open to investor conversations'},
]

export default function MatchingPage() {
  const [intent, setIntent] = useState('general')
  const [profiles, setProfiles] = useState<any[]>([])
  const [matches, setMatches] = useState<any[]>([])
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState('')
  const [msg, setMsg] = useState('')

  const [showEdit, setShowEdit] = useState(false)
  const [tagsInput, setTagsInput] = useState('')
  const [description, setDescription] = useState('')
  const [saving, setSaving] = useState(false)

  const myProfile = profiles.find(p => p.intent === intent)

  const fetchAll = async () => {
    setLoading(true); setError('')
    try {
      const res = await MatchingAPI.myProfiles()
      setProfiles(res.items || res || [])
    } catch (e: any) { setError(e.message) }
    finally { setLoading(false) }
  }

  const fetchMatches = async (forIntent: string) => {
    try {
      const res = await MatchingAPI.matches(forIntent)
      setMatches(res.items || res || [])
    } catch { setMatches([]) }
  }

  useEffect(() => { fetchAll() }, [])
  useEffect(() => {
    const p = profiles.find(p => p.intent === intent)
    if (p) fetchMatches(intent); else setMatches([])
  }, [intent, profiles])

  const openEdit = () => {
    setTagsInput((myProfile?.tags || []).join(', '))
    setDescription(myProfile?.description || '')
    setShowEdit(true)
  }

  const saveProfile = async () => {
    const tags = tagsInput.split(',').map(t=>t.trim()).filter(Boolean)
    if (tags.length === 0) { setMsg('❌ Add at least one tag'); return }
    setSaving(true)
    try {
      await MatchingAPI.upsertProfile({ intent, tags, description })
      setShowEdit(false)
      setMsg('✅ Profile saved — finding matches…')
      await fetchAll()
    } catch (e: any) { setMsg('❌ ' + e.message) }
    finally { setSaving(false) }
  }

  const removeProfile = async () => {
    if (!confirm('Remove your matching profile for this category?')) return
    try {
      await MatchingAPI.deleteProfile(intent)
      setMsg('✅ Profile removed')
      fetchAll()
    } catch (e: any) { setMsg('❌ ' + e.message) }
  }

  const current = INTENTS.find(i => i.id === intent)!

  return (
    <div className="page">
      <div style={{marginBottom:16}}>
        <h2 style={{fontSize:18,fontWeight:800}}>Member Matching</h2>
        <p style={{fontSize:13,color:'#9ca3af'}}>Tag-based matching — add what you need or offer, and we'll surface members with overlapping tags</p>
      </div>

      {msg && (
        <div className="toast-in" style={{padding:'10px 14px',borderRadius:10,marginBottom:12,fontSize:13,
          background:msg.startsWith('✅')?'rgba(39,216,109,.1)':'rgba(255,90,90,.1)',
          color:msg.startsWith('✅')?'#16a34a':'#ef4444',
          border:`1px solid ${msg.startsWith('✅')?'rgba(39,216,109,.35)':'rgba(255,90,90,.35)'}`}}>
          {msg}<button style={{marginLeft:12,background:'none',border:'none',cursor:'pointer',color:'#9ca3af'}} onClick={()=>setMsg('')}>✕</button>
        </div>
      )}

      <div style={{display:'grid',gridTemplateColumns:'repeat(3,1fr)',gap:10,marginBottom:16}}>
        {INTENTS.map(i=>(
          <div key={i.id} onClick={()=>setIntent(i.id)}
            style={{border:`2px solid ${intent===i.id?'var(--nx-orange)':'var(--nx-line)'}`,borderRadius:12,padding:14,cursor:'pointer',background:intent===i.id?'#fff8f6':'#fff'}}>
            <div style={{fontSize:14,fontWeight:700,marginBottom:4}}><FontAwesomeIcon icon={i.ic} className="mr-1.5"/>{i.l}</div>
            <div style={{fontSize:11,color:'#9ca3af'}}>{i.desc}</div>
          </div>
        ))}
      </div>

      {loading ? <Loading label="Loading your profiles…"/> : error ? <ApiError message={error} onRetry={fetchAll}/> : (
        <>
          <div className="card" style={{marginBottom:16}}>
            {!myProfile ? (
              <div style={{textAlign:'center',padding:20}}>
                <div style={{fontSize:13,color:'#9ca3af',marginBottom:10}}>You haven't set up a {current.l.replace(/^\S+\s/,'')} profile yet</div>
                <button className="btn btn-p btn-sm" onClick={openEdit}>+ Create Profile</button>
              </div>
            ) : (
              <>
                <div style={{display:'flex',justifyContent:'space-between',alignItems:'flex-start'}}>
                  <div>
                    <div style={{fontSize:12,fontWeight:700,color:'#9ca3af',marginBottom:6}}>YOUR TAGS</div>
                    <div style={{display:'flex',gap:6,flexWrap:'wrap',marginBottom:8}}>
                      {myProfile.tags.map((t:string)=><span key={t} className="badge b-blue">{t}</span>)}
                    </div>
                    {myProfile.description && <div style={{fontSize:13,color:'#cbd5e1'}}>{myProfile.description}</div>}
                  </div>
                  <div style={{display:'flex',gap:6}}>
                    <button className="btn btn-g btn-sm" onClick={openEdit}>Edit</button>
                    <button className="btn btn-g btn-sm" style={{color:'#ef4444'}} onClick={removeProfile}>Delete</button>
                  </div>
                </div>
              </>
            )}
          </div>

          {myProfile && (
            <>
              <div style={{fontSize:14,fontWeight:700,marginBottom:10}}>Matches ({matches.length})</div>
              {matches.length === 0 ? (
                <Empty label="No overlapping tags yet — try broadening yours, or check back as more members join"/>
              ) : (
                <div style={{display:'flex',flexDirection:'column',gap:10}}>
                  {matches.map((m:any)=>(
                    <div key={m.id} className="card">
                      <div style={{display:'flex',gap:12,alignItems:'flex-start'}}>
                        <div style={{width:40,height:40,borderRadius:'50%',background:'#6366f1',display:'flex',alignItems:'center',justifyContent:'center',color:'#fff',fontWeight:700,flexShrink:0}}>
                          {m.user?.name?.charAt(0)||'?'}
                        </div>
                        <div style={{flex:1}}>
                          <div style={{display:'flex',justifyContent:'space-between',alignItems:'center'}}>
                            <span style={{fontWeight:700,fontSize:14}}>{m.user?.name || 'NIA Member'}</span>
                            <span className="badge b-green">Match score {m.match_score}</span>
                          </div>
                          <div style={{display:'flex',gap:6,flexWrap:'wrap',margin:'6px 0'}}>
                            {m.tags.map((t:string)=><span key={t} className={`badge ${myProfile.tags.includes(t)?'b-green':'b-gray'}`}>{t}</span>)}
                          </div>
                          {m.match_reasons?.length > 0 && (
                            <div style={{fontSize:11,color:'#9ca3af',marginBottom:8}}>
                              ✨ {m.match_reasons.join(' · ')}
                            </div>
                          )}
                          {m.description && <div style={{fontSize:12,color:'#6b7280',marginBottom:8}}>{m.description}</div>}
                          <button className="btn btn-p btn-sm" onClick={()=>window.location.href=`/dashboard/messages?to=${m.user_id}&name=${encodeURIComponent(m.user?.name||'')}`}><FontAwesomeIcon icon={faComment} className="mr-1.5"/>Message</button>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </>
          )}
        </>
      )}

      {showEdit && (
        <div className="overlay" onClick={e=>e.target===e.currentTarget&&setShowEdit(false)}>
          <div className="modal">
            <h3 style={{fontSize:16,fontWeight:700,marginBottom:14}}>{current.l}</h3>
            <div className="fg">
              <label>Tags (comma-separated) *</label>
              <input value={tagsInput} onChange={e=>setTagsInput(e.target.value)} placeholder="fintech, saas, delhi, b2b"/>
            </div>
            <div className="fg">
              <label>What are you looking for?</label>
              <textarea rows={3} value={description} onChange={e=>setDescription(e.target.value)} placeholder="Briefly describe what you need or offer…"/>
            </div>
            <div style={{display:'flex',gap:8}}>
              <button className="btn btn-p" style={{flex:1}} onClick={saveProfile} disabled={saving}>{saving?'Saving…':'Save Profile'}</button>
              <button className="btn btn-g" style={{flex:1}} onClick={()=>setShowEdit(false)}>Cancel</button>
            </div>
          </div>
        </div>
      )}
    </div>
  )
}
