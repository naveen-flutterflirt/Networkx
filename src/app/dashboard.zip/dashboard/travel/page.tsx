'use client'
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome'
import { faArrowLeft, faBullseye, faComment, faHandshake, faLocationDot, faPenToSquare,
  faPlane, faCalendarDays, faArrowRight } from '@fortawesome/free-solid-svg-icons'
import { useState, useEffect } from 'react'
import { TravelAPI, TokenStore } from '@/lib/api'

const INDIAN_CITIES = ['Ahmedabad','Bangalore','Bhopal','Chennai','Delhi','Gurgaon','Hyderabad','Indore','Jaipur','Kochi','Kolkata','Lucknow','Mumbai','Nagpur','Noida','Pune','Surat','Vadodara']
const INTL_CITIES   = ['Dubai','Singapore','London','New York','Toronto','Sydney','Frankfurt','Tokyo','Bangkok','Kuala Lumpur','Hong Kong']
const ALL_CITIES    = [...INDIAN_CITIES, '—', ...INTL_CITIES]
const PURPOSES      = ['Client Meetings','Conference / Summit','Business Development','Personal Travel','Medical','Family','Training','Tourism']

type TravelFormData = {
  from: string
  to: string
  start_date: string
  end_date: string
  purpose: string
  looking_for: string
  notes: string
}

type TravelFormErrors = Partial<Record<keyof TravelFormData, string>>

// Validates a travel form and returns a map of field -> error message.
// An empty object means the form is valid and safe to submit.
function validateTravelForm(data: TravelFormData): TravelFormErrors {
  const errors: TravelFormErrors = {}
  if (!data.from) errors.from = 'From city is required'
  if (!data.to) errors.to = 'To city is required'
  if (data.from && data.to && data.from === data.to) errors.to = 'To city must be different from From city'
  if (!data.purpose) errors.purpose = 'Purpose of travel is required'
  if (data.start_date && data.end_date && new Date(data.end_date) < new Date(data.start_date)) {
    errors.end_date = 'Return date cannot be before departure date'
  }
  if (data.looking_for && data.looking_for.length > 500) errors.looking_for = 'Keep this under 500 characters'
  if (data.notes && data.notes.length > 500) errors.notes = 'Keep this under 500 characters'
  return errors
}

// Defined OUTSIDE the page component (not nested inside TravelPage) so React
// treats it as a stable component reference across re-renders. Previously
// this was declared inside TravelPage, which recreated the component (and
// its inputs/textareas) on every keystroke, causing the "Looking For" /
// "Additional Notes" textareas to lose focus after each character typed.
function TravelForm({ data, errors, onChange }: {
  data: TravelFormData
  errors: TravelFormErrors
  onChange: (d: TravelFormData) => void
}) {
  return (
    <>
      <div className="form-grid">
        <div className="fg">
          <label>From City *</label>
          <select value={data.from} onChange={e=>onChange({...data,from:e.target.value})}>
            <option value="">— Select city —</option>
            <optgroup label="India">{INDIAN_CITIES.map(c=><option key={c}>{c}</option>)}</optgroup>
            <optgroup label="International">{INTL_CITIES.map(c=><option key={c}>{c}</option>)}</optgroup>
          </select>
          {errors.from && <div className="field-error">{errors.from}</div>}
        </div>
        <div className="fg">
          <label>To City *</label>
          <select value={data.to} onChange={e=>onChange({...data,to:e.target.value})}>
            <option value="">— Select city —</option>
            <optgroup label="India">{INDIAN_CITIES.map(c=><option key={c}>{c}</option>)}</optgroup>
            <optgroup label="International">{INTL_CITIES.map(c=><option key={c}>{c}</option>)}</optgroup>
          </select>
          {errors.to && <div className="field-error">{errors.to}</div>}
        </div>
        <div className="fg">
          <label>Departure Date</label>
          <input type="date" value={data.start_date||''} onChange={e=>onChange({...data,start_date:e.target.value})}/>
        </div>
        <div className="fg">
          <label>Return Date</label>
          <input type="date" value={data.end_date||''} onChange={e=>onChange({...data,end_date:e.target.value})}/>
          {errors.end_date && <div className="field-error">{errors.end_date}</div>}
        </div>
        <div className="fg" style={{gridColumn:'1/-1'}}>
          <label>Purpose of Travel *</label>
          <select value={data.purpose} onChange={e=>onChange({...data,purpose:e.target.value})}>
            {PURPOSES.map(p=><option key={p}>{p}</option>)}
          </select>
          {errors.purpose && <div className="field-error">{errors.purpose}</div>}
        </div>
      </div>
      <div className="fg">
        <label>Looking For</label>
        <textarea rows={2} value={data.looking_for||''} onChange={e=>onChange({...data,looking_for:e.target.value})}
          placeholder="Introductions to CA firms, co-working space, local members to meet…"/>
        {errors.looking_for && <div className="field-error">{errors.looking_for}</div>}
      </div>
      <div className="fg">
        <label>Additional Notes</label>
        <textarea rows={2} value={data.notes||''} onChange={e=>onChange({...data,notes:e.target.value})}
          placeholder="Flight details, hotel area, preferred meeting times…"/>
        {errors.notes && <div className="field-error">{errors.notes}</div>}
      </div>
    </>
  )
}

export default function TravelPage() {
  const [posts,    setPosts]    = useState<any[]>([])
  const [loading,  setLoading]  = useState(true)
  const [error,    setError]    = useState('')
  const [msg,      setMsg]      = useState('')
  const [page,     setPage]     = useState(1)
  const [hasMore,  setHasMore]  = useState(false)
  const [cityFilter,  setCityFilter]  = useState('')
  const [purposeFilter,setPurposeFilter] = useState('')
  const [myCity,       setMyCity]        = useState('')
  const [showForm, setShowForm] = useState(false)
  const [editing,  setEditing]  = useState<any|null>(null)
  const [saving,   setSaving]   = useState(false)
  const [formErrors,   setFormErrors]   = useState<TravelFormErrors>({})
  const [editErrors,   setEditErrors]   = useState<TravelFormErrors>({})

  const me = TokenStore.getUser()

  const emptyForm: TravelFormData = {
    from:'', to:'', start_date:'', end_date:'',
    purpose:'Client Meetings', looking_for:'', notes:''
  }
  const [form, setForm] = useState<TravelFormData>(emptyForm)

  const fetchPosts = async (p = 1) => {
    setLoading(true); setError('')
    try {
      const res = await TravelAPI.list({ page: p, page_size: 20 })
      const all = res.items || res
      let filtered = cityFilter
        ? all.filter((t: any) => t.from===cityFilter || t.to===cityFilter)
        : all
      if (purposeFilter) filtered = filtered.filter((t: any) => t.purpose===purposeFilter)
      setPosts(filtered)
      setHasMore(res.has_more || false)
      setPage(p)
    } catch (e: any) { setError(e.message) }
    finally { setLoading(false) }
  }

  useEffect(() => {
    const u = TokenStore.getUser()
    setMyCity(u?.city || '')
    fetchPosts(1)
  }, [cityFilter, purposeFilter])

  const createPost = async () => {
    const errs = validateTravelForm(form)
    setFormErrors(errs)
    if (Object.keys(errs).length > 0) return
    setSaving(true)
    try {
      await TravelAPI.create(form)
      setShowForm(false)
      setForm(emptyForm)
      setFormErrors({})
      setMsg('✅ Travel announced!')
      fetchPosts(1)
    } catch (e: any) { setMsg('❌ ' + e.message) }
    finally { setSaving(false) }
  }

  const saveEdit = async () => {
    if (!editing) return
    const errs = validateTravelForm(editing)
    setEditErrors(errs)
    if (Object.keys(errs).length > 0) return
    setSaving(true)
    try {
      await TravelAPI.update(editing.id, editing)
      setEditing(null)
      setEditErrors({})
      setMsg('✅ Travel post updated!')
      fetchPosts(page)
    } catch (e: any) { setMsg('❌ ' + e.message) }
    finally { setSaving(false) }
  }

  const connect = async (id: string, name: string) => {
    try {
      await TravelAPI.connect(id)
      setMsg(`✅ Connection request sent to ${name}!`)
    } catch (e: any) { setMsg('❌ ' + e.message) }
  }

  const deletePost = async (id: string) => {
    if (!confirm('Delete this travel post?')) return
    try {
      await TravelAPI.delete(id)
      setMsg('✅ Travel post deleted')
      fetchPosts(page)
    } catch (e: any) { setMsg('❌ ' + e.message) }
  }

  return (
    <div className="page">
      <div style={{display:'flex',justifyContent:'space-between',alignItems:'center',marginBottom:16}}>
        <div>
          <h2 style={{fontSize:18,fontWeight:800}}>Travel Connect</h2>
          <p style={{fontSize:13,color:'#9ca3af'}}>Network while you travel — get intros to members at your destination</p>
        </div>
        <button className="btn btn-p" onClick={()=>{setForm(emptyForm);setFormErrors({});setShowForm(true)}}>+ Announce Travel</button>
      </div>

      {/* Banner */}
      <div style={{background:'linear-gradient(135deg,#fff8f6,#fff0eb)',borderRadius:12,padding:16,marginBottom:16,
        border:'1px solid #ffe8e0',display:'flex',alignItems:'center',gap:12}}>
        <span style={{fontSize:28}}><FontAwesomeIcon icon={faPlane}/></span>
        <div style={{flex:1}}>
          <div style={{fontWeight:700}}>Travelling soon? Let your network know!</div>
          <div style={{fontSize:12,color:'#9ca3af'}}>NIA members at your destination will arrange meetings, intros and local connections.</div>
        </div>
      </div>

      {msg && (
        <div className="toast-in" style={{padding:'10px 14px',borderRadius:10,marginBottom:12,fontSize:13,
          background:msg.startsWith('✅')?'rgba(39,216,109,.1)':'rgba(255,90,90,.1)',
          color:msg.startsWith('✅')?'#16a34a':'#ef4444',
          border:`1px solid ${msg.startsWith('✅')?'rgba(39,216,109,.35)':'rgba(255,90,90,.35)'}`}}>
          {msg}<button style={{marginLeft:12,background:'none',border:'none',cursor:'pointer',color:'#9ca3af'}} onClick={()=>setMsg('')}>✕</button>
        </div>
      )}
      {error && <div style={{background:'rgba(255,90,90,.1)',border:'1px solid rgba(255,90,90,.3)',borderRadius:10,padding:'10px 14px',marginBottom:12,color:'#ef4444',fontSize:13}}>{error}</div>}

      {/* My city quick filter */}
      {myCity && (
        <div style={{background:'rgba(0,191,248,.08)',border:'1px solid #bae6fd',borderRadius:10,padding:'10px 14px',marginBottom:12,fontSize:13,display:'flex',justifyContent:'space-between',alignItems:'center'}}>
          <span><FontAwesomeIcon icon={faLocationDot} className="mr-1.5"/>Members travelling to <strong>{myCity}</strong>: {posts.filter(t=>t.to===myCity).length} posts</span>
          <button className="btn btn-p btn-sm" onClick={()=>setCityFilter(myCity)}>Show Only <FontAwesomeIcon icon={faArrowRight} className="mx-1"/>{myCity}</button>
        </div>
      )}

      {/* City filter */}
      <div style={{display:'flex',gap:6,flexWrap:'wrap',marginBottom:8}}>
        <button className={`btn btn-sm ${cityFilter===''?'btn-p':'btn-g'}`} onClick={()=>setCityFilter('')}>All Cities</button>
        {[...INDIAN_CITIES.slice(0,8),...INTL_CITIES.slice(0,3)].map(c=>(
          <button key={c} className={`btn btn-sm ${cityFilter===c?'btn-p':'btn-g'}`} onClick={()=>setCityFilter(cityFilter===c?'':c)}>{c}</button>
        ))}
      </div>

      {/* Purpose filter */}
      <div style={{display:'flex',gap:6,flexWrap:'wrap',marginBottom:14}}>
        <button className={`btn btn-sm ${purposeFilter===''?'btn-p':'btn-g'}`} onClick={()=>setPurposeFilter('')}>All Purposes</button>
        {PURPOSES.map(p=>(
          <button key={p} className={`btn btn-sm ${purposeFilter===p?'btn-p':'btn-g'}`} onClick={()=>setPurposeFilter(purposeFilter===p?'':p)}>{p}</button>
        ))}
      </div>

      {/* Travel posts */}
      <div style={{display:'flex',flexDirection:'column',gap:12}}>
        {loading
          ? [...Array(3)].map((_,i)=><div key={i} className="card" style={{height:140,background:'rgba(255,255,255,.06)'}}/>)
          : posts.length===0
          ? <div className="card" style={{textAlign:'center',padding:48,color:'#9ca3af'}}>
              <div style={{fontSize:40,marginBottom:12}}><FontAwesomeIcon icon={faPlane}/></div>
              <div style={{fontWeight:600,marginBottom:4}}>{cityFilter?`No travel posts for ${cityFilter}`:'No travel posts yet'}</div>
              <button className="btn btn-p btn-sm" style={{marginTop:8}} onClick={()=>{setForm(emptyForm);setFormErrors({});setShowForm(true)}}>Announce Your Travel</button>
            </div>
          : posts.map(t=>{
            const isOwn = t.user_id === me?.id
            const isUpcoming = t.start_date && new Date(t.start_date) > new Date()
            return (
              <div key={t.id} className="card" style={{borderLeft:`3px solid ${isUpcoming?'var(--nx-orange)':'#10b981'}`}}>
                <div style={{display:'flex',gap:12,alignItems:'flex-start'}}>
                  <div style={{width:44,height:44,borderRadius:'50%',background:'#6366f1',
                    display:'flex',alignItems:'center',justifyContent:'center',color:'#fff',fontSize:14,fontWeight:700,flexShrink:0}}>
                    {t.user?.name?.charAt(0)||'?'}
                  </div>
                  <div style={{flex:1}}>
                    <div style={{display:'flex',justifyContent:'space-between',alignItems:'flex-start',marginBottom:4}}>
                      <div>
                        <span style={{fontWeight:700,fontSize:14}}>{t.user?.name||'NIA Member'}</span>
                        {isOwn && <span style={{marginLeft:8,fontSize:10,padding:'1px 6px',borderRadius:99,background:'rgba(22,143,255,.1)',color:'#3b82f6',fontWeight:600}}>You</span>}
                      </div>
                      <span style={{fontSize:11,color:'#9ca3af'}}>{t.created_at?new Date(t.created_at).toLocaleDateString():'—'}</span>
                    </div>
                    {/* Route */}
                    <div style={{fontSize:15,marginBottom:4,display:'flex',alignItems:'center',gap:8}}>
                      <span style={{fontWeight:700}}>{t.from}</span>
                      <span style={{color:'#9ca3af',fontSize:13}}><FontAwesomeIcon icon={faPlane}/></span>
                      <span style={{fontWeight:700,color:'var(--nx-orange)'}}>{t.to}</span>
                    </div>
                    {/* Dates */}
                    {(t.start_date||t.end_date) && (
                      <div style={{fontSize:12,color:'#6b7280',marginBottom:4}}>
                        <FontAwesomeIcon icon={faCalendarDays} className="mr-1"/>{t.start_date?new Date(t.start_date).toLocaleDateString():'?'}
                        {t.end_date ? ` → ${new Date(t.end_date).toLocaleDateString()}` : ''}
                        {isUpcoming && <span style={{marginLeft:8,fontSize:10,padding:'1px 6px',borderRadius:99,background:'rgba(255,75,10,.1)',color:'#c2410c',fontWeight:600}}>Upcoming</span>}
                      </div>
                    )}
                    {/* Purpose */}
                    {t.purpose && <div style={{fontSize:12,color:'#6b7280',marginBottom:4}}><FontAwesomeIcon icon={faBullseye} className="mr-1.5"/>{t.purpose}</div>}
                    {/* Looking for */}
                    {t.looking_for && (
                      <div style={{marginTop:8,background:'rgba(255,255,255,.04)',borderRadius:8,padding:'8px 10px',fontSize:12,color:'#cbd5e1'}}>
                        <span style={{fontWeight:700,color:'#9ca3af',fontSize:10}}>LOOKING FOR: </span>{t.looking_for}
                      </div>
                    )}
                    {/* Notes */}
                    {t.notes && (
                      <div style={{marginTop:4,fontSize:12,color:'#9ca3af'}}><FontAwesomeIcon icon={faPenToSquare} className="mr-1.5"/>{t.notes}</div>
                    )}
                    {/* Actions */}
                    <div style={{display:'flex',gap:8,marginTop:10,flexWrap:'wrap'}}>
                      {!isOwn && (
                        <>
                          <button className="btn btn-p btn-sm" onClick={()=>connect(t.id,t.user?.name||'member')}><FontAwesomeIcon icon={faHandshake} className="mr-1.5"/>Connect</button>
                          <button className="btn btn-g btn-sm" onClick={()=>window.location.href=`/dashboard/messages?to=${t.user_id}&name=${encodeURIComponent(t.user?.name||'')}`}><FontAwesomeIcon icon={faComment} className="mr-1.5"/>Message</button>
                        </>
                      )}
                      {isOwn && (
                        <>
                          <button className="btn btn-g btn-sm" style={{color:'#6366f1'}} onClick={()=>{setEditErrors({});setEditing({...t})}}>✏️ Edit</button>
                          <button className="btn btn-g btn-sm" style={{color:'#ef4444'}} onClick={()=>deletePost(t.id)}>Delete</button>
                        </>
                      )}
                    </div>
                  </div>
                </div>
              </div>
            )
          })
        }
      </div>

      {/* Pagination */}
      <div style={{display:'flex',gap:6,justifyContent:'center',marginTop:12}}>
        <button className="btn btn-g btn-sm" disabled={page===1} onClick={()=>fetchPosts(page-1)}><FontAwesomeIcon icon={faArrowLeft} className="mr-1.5"/>Prev</button>
        <span style={{padding:'6px 12px',fontSize:13,color:'#9ca3af'}}>Page {page}</span>
        <button className="btn btn-g btn-sm" disabled={!hasMore} onClick={()=>fetchPosts(page+1)}>Next <FontAwesomeIcon icon={faArrowRight} className="ml-1"/></button>
      </div>

      {/* ── CREATE MODAL ─────────────────────────────────────────────── */}
      {showForm && (
        <div className="overlay" onClick={e=>e.target===e.currentTarget&&setShowForm(false)}>
          <div className="modal modal-lg">
            <h3 style={{fontSize:16,fontWeight:700,marginBottom:14}}><FontAwesomeIcon icon={faPlane} className="mr-1.5"/>Announce Your Travel</h3>
            <TravelForm data={form} errors={formErrors} onChange={setForm}/>
            <div style={{display:'flex',gap:8,marginTop:8}}>
              <button className="btn btn-p" style={{flex:1}} onClick={createPost} disabled={saving}>
                {saving?'Announcing…':'Announce Travel'}
              </button>
              <button className="btn btn-g" style={{flex:1}} onClick={()=>{setShowForm(false);setFormErrors({})}}>Cancel</button>
            </div>
          </div>
        </div>
      )}

      {/* ── EDIT MODAL ───────────────────────────────────────────────── */}
      {editing && (
        <div className="overlay" onClick={e=>e.target===e.currentTarget&&setEditing(null)}>
          <div className="modal modal-lg">
            <h3 style={{fontSize:16,fontWeight:700,marginBottom:14}}>Edit Travel Post</h3>
            <TravelForm data={editing} errors={editErrors} onChange={setEditing}/>
            <div style={{display:'flex',gap:8,marginTop:8}}>
              <button className="btn btn-p" style={{flex:1}} onClick={saveEdit} disabled={saving}>
                {saving?'Saving…':'Save Changes'}
              </button>
              <button className="btn btn-g" style={{flex:1}} onClick={()=>{setEditing(null);setEditErrors({})}}>Cancel</button>
            </div>
          </div>
        </div>
      )}
    </div>
  )
}
