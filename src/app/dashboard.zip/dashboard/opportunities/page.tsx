'use client'
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome'
import { faCalendarDays, faMicrophone, faBullseye, faLandmark, faClipboard } from '@fortawesome/free-solid-svg-icons'
import { useState, useEffect } from 'react'
import { OpportunitiesAPI, TokenStore } from '@/lib/api'
import { Loading, ApiError, Empty } from '@/components/shared/States'

const TYPES = [
  {id:'speaking',            l:'Speaking Opportunities', ic:faMicrophone, desc:'Selection-based speaking slots'},
  {id:'pitch_practice',      l:'Pitch Practice', ic:faBullseye,          desc:'Online sessions, paid for all tiers'},
  {id:'gem_support',         l:'GeM Portal Support', ic:faLandmark,      desc:'Elite tier — paid onboarding help'},
  {id:'investor_readiness',  l:'Investor Readiness', ic:faClipboard,      desc:'Self-serve checklist'},
]

export default function OpportunitiesPage() {
  const me = TokenStore.getUser()
  const canManage = ['franchise','hq_admin','super_admin'].includes(me?.role)

  const [type, setType] = useState('speaking')
  const [items, setItems] = useState<any[]>([])
  const [myApps, setMyApps] = useState<any[]>([])
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState('')
  const [msg, setMsg] = useState('')

  const [checklist, setChecklist] = useState<any[]>([])
  const [completed, setCompleted] = useState<string[]>([])

  const [showApply, setShowApply] = useState<any|null>(null)
  const [pitch, setPitch] = useState('')
  const [applying, setApplying] = useState(false)

  const [showCreate, setShowCreate] = useState(false)
  const emptyForm = {title:'',description:'',date:'',tier_required:'',is_paid:false,price:''}
  const [form, setForm] = useState<any>(emptyForm)
  const [saving, setSaving] = useState(false)

  const fetchForType = async (t: string) => {
    setLoading(true); setError('')
    try {
      if (t === 'investor_readiness') {
        const res = await OpportunitiesAPI.readinessProgress()
        setChecklist(res.checklist || [])
        setCompleted(res.completed_items || [])
      } else {
        const [listRes, appsRes] = await Promise.all([
          OpportunitiesAPI.list(t),
          OpportunitiesAPI.myApplications().catch(()=>({items:[]})),
        ])
        setItems(listRes.items || listRes || [])
        setMyApps((appsRes.items || appsRes || []).filter((a:any)=>a.opportunity_type===t))
      }
    } catch (e: any) { setError(e.message) }
    finally { setLoading(false) }
  }

  useEffect(() => { fetchForType(type) }, [type])

  const toggleItem = async (itemId: string, isDone: boolean) => {
    try {
      const res = await OpportunitiesAPI.toggleReadiness(itemId, !isDone)
      setCompleted(res.completed_items || [])
    } catch (e: any) { setMsg('❌ ' + e.message) }
  }

  const submitApply = async () => {
    if (!showApply) return
    setApplying(true)
    try {
      await OpportunitiesAPI.apply(showApply.id, { pitch })
      setMsg('✅ Application submitted!')
      setShowApply(null); setPitch('')
      fetchForType(type)
    } catch (e: any) { setMsg('❌ ' + e.message) }
    finally { setApplying(false) }
  }

  const createOpportunity = async () => {
    if (!form.title) { setMsg('❌ Title is required'); return }
    setSaving(true)
    try {
      await OpportunitiesAPI.create({...form, type, tier_required: form.tier_required || null, price: form.price ? Number(form.price) : null})
      setShowCreate(false); setForm(emptyForm)
      setMsg('✅ Opportunity posted!')
      fetchForType(type)
    } catch (e: any) { setMsg('❌ ' + e.message) }
    finally { setSaving(false) }
  }

  const current = TYPES.find(t=>t.id===type)!
  const appliedIds = myApps.map(a=>a.opportunity_id)
  const doneCount = completed.length

  return (
    <div className="page">
      <div style={{display:'flex',justifyContent:'space-between',alignItems:'center',marginBottom:16}}>
        <div>
          <h2 style={{fontSize:18,fontWeight:800}}>Opportunities</h2>
          <p style={{fontSize:13,color:'#9ca3af'}}>Speaking slots, pitch practice, GeM support, and investor readiness</p>
        </div>
        {canManage && type!=='investor_readiness' && <button className="btn btn-p" onClick={()=>{setForm(emptyForm);setShowCreate(true)}}>+ Post Opportunity</button>}
      </div>

      {msg && (
        <div className="toast-in" style={{padding:'10px 14px',borderRadius:10,marginBottom:12,fontSize:13,
          background:msg.startsWith('✅')?'rgba(39,216,109,.1)':'rgba(255,90,90,.1)',
          color:msg.startsWith('✅')?'#16a34a':'#ef4444',
          border:`1px solid ${msg.startsWith('✅')?'rgba(39,216,109,.35)':'rgba(255,90,90,.35)'}`}}>
          {msg}<button style={{marginLeft:12,background:'none',border:'none',cursor:'pointer',color:'#9ca3af'}} onClick={()=>setMsg('')}>✕</button>
        </div>
      )}

      <div style={{display:'grid',gridTemplateColumns:'repeat(4,1fr)',gap:10,marginBottom:16}}>
        {TYPES.map(t=>(
          <div key={t.id} onClick={()=>setType(t.id)}
            style={{border:`2px solid ${type===t.id?'var(--nx-orange)':'var(--nx-line)'}`,borderRadius:12,padding:12,cursor:'pointer',textAlign:'center',background:type===t.id?'#fff8f6':'#fff'}}>
            <div style={{fontSize:20,marginBottom:4}}><FontAwesomeIcon icon={t.ic}/></div>
            <div style={{fontSize:11,fontWeight:600}}>{t.l}</div>
            <div style={{fontSize:10,color:'#9ca3af',marginTop:2}}>{t.desc}</div>
          </div>
        ))}
      </div>

      {loading ? <Loading label="Loading…"/> : error ? <ApiError message={error} onRetry={()=>fetchForType(type)}/> :
       type === 'investor_readiness' ? (
        <div className="card">
          <div style={{display:'flex',justifyContent:'space-between',alignItems:'center',marginBottom:14}}>
            <div style={{fontWeight:700,fontSize:14}}>Readiness Checklist</div>
            <span className="badge b-blue">{doneCount}/{checklist.length} complete</span>
          </div>
          <div className="prog" style={{marginBottom:16}}><div className="prog-fill" style={{width:`${checklist.length?(doneCount/checklist.length*100):0}%`}}/></div>
          <div style={{display:'flex',flexDirection:'column',gap:8}}>
            {checklist.map(item=>{
              const isDone = completed.includes(item.id)
              return (
                <div key={item.id} onClick={()=>toggleItem(item.id, isDone)}
                  style={{display:'flex',alignItems:'center',gap:10,padding:'10px 12px',borderRadius:8,cursor:'pointer',background:isDone?'rgba(39,216,109,.1)':'rgba(255,255,255,.04)',border:`1px solid ${isDone?'rgba(39,216,109,.35)':'var(--nx-line)'}`}}>
                  <span style={{fontSize:16}}>{isDone?'✅':'⬜'}</span>
                  <span style={{fontSize:13,textDecoration:isDone?'line-through':'none',color:isDone?'#16a34a':'#cbd5e1'}}>{item.label}</span>
                </div>
              )
            })}
          </div>
        </div>
       ) : items.length === 0 ? (
        <Empty label={`No ${current.l.replace(/^\S+\s/,'')} open right now`}/>
       ) : (
        <div style={{display:'flex',flexDirection:'column',gap:12}}>
          {items.map(o=>{
            const applied = appliedIds.includes(o.id)
            return (
              <div key={o.id} className="card">
                <div style={{display:'flex',justifyContent:'space-between',alignItems:'flex-start',marginBottom:6}}>
                  <div style={{fontSize:15,fontWeight:700}}>{o.title}</div>
                  <div style={{display:'flex',gap:6}}>
                    {o.is_paid && <span className="badge b-yellow">{o.price ? `₹${o.price}` : 'Paid'}</span>}
                    {o.tier_required && <span className="badge b-blue">{o.tier_required.replace('_',' ')}+</span>}
                  </div>
                </div>
                {o.date && <div style={{fontSize:12,color:'#9ca3af',marginBottom:6}}><FontAwesomeIcon icon={faCalendarDays} className="mr-1.5"/>{o.date}</div>}
                {o.description && <div style={{fontSize:13,color:'#cbd5e1',marginBottom:10}}>{o.description}</div>}
                <button className="btn btn-p btn-sm" disabled={applied} onClick={()=>{setPitch('');setShowApply(o)}}>
                  {applied ? '✅ Applied' : 'Apply'}
                </button>
              </div>
            )
          })}
        </div>
      )}

      {showApply && (
        <div className="overlay" onClick={e=>e.target===e.currentTarget&&setShowApply(null)}>
          <div className="modal">
            <h3 style={{fontSize:16,fontWeight:700,marginBottom:14}}>Apply — {showApply.title}</h3>
            <div className="fg">
              <label>Why should you be selected?</label>
              <textarea rows={4} value={pitch} onChange={e=>setPitch(e.target.value)} placeholder="Tell us briefly…"/>
            </div>
            <div style={{display:'flex',gap:8}}>
              <button className="btn btn-p" style={{flex:1}} onClick={submitApply} disabled={applying}>{applying?'Submitting…':'Submit Application'}</button>
              <button className="btn btn-g" style={{flex:1}} onClick={()=>setShowApply(null)}>Cancel</button>
            </div>
          </div>
        </div>
      )}

      {showCreate && (
        <div className="overlay" onClick={e=>e.target===e.currentTarget&&setShowCreate(false)}>
          <div className="modal">
            <h3 style={{fontSize:16,fontWeight:700,marginBottom:14}}><FontAwesomeIcon icon={current.ic} className="mr-1.5"/>Post {current.l}</h3>
            <div className="fg"><label>Title *</label><input value={form.title} onChange={e=>setForm({...form,title:e.target.value})}/></div>
            <div className="fg"><label>Description</label><textarea rows={3} value={form.description} onChange={e=>setForm({...form,description:e.target.value})}/></div>
            <div className="form-grid">
              <div className="fg"><label>Date</label><input type="date" value={form.date} onChange={e=>setForm({...form,date:e.target.value})}/></div>
              <div className="fg">
                <label>Min Tier</label>
                <select value={form.tier_required} onChange={e=>setForm({...form,tier_required:e.target.value})}>
                  <option value="">All tiers</option>
                  <option value="growth">Growth+</option>
                  <option value="elite">Elite+</option>
                </select>
              </div>
            </div>
            <div className="fg" style={{display:'flex',alignItems:'center',gap:8}}>
              <input type="checkbox" checked={form.is_paid} onChange={e=>setForm({...form,is_paid:e.target.checked})} style={{width:'auto'}}/>
              <label style={{marginBottom:0}}>Paid opportunity</label>
            </div>
            {form.is_paid && <div className="fg"><label>Price (₹)</label><input type="number" value={form.price} onChange={e=>setForm({...form,price:e.target.value})}/></div>}
            <div style={{display:'flex',gap:8,marginTop:8}}>
              <button className="btn btn-p" style={{flex:1}} onClick={createOpportunity} disabled={saving}>{saving?'Posting…':'Post'}</button>
              <button className="btn btn-g" style={{flex:1}} onClick={()=>setShowCreate(false)}>Cancel</button>
            </div>
          </div>
        </div>
      )}
    </div>
  )
}
