'use client'
import { useState, useEffect } from 'react'
import { getUser } from '@/lib/auth'
import { initAutoRefresh, stopAutoRefresh, TokenStore, ProfileAPI } from '@/lib/api'
import { User } from '@/lib/data'
import Sidebar from '@/components/layout/Sidebar'
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome'
import { faUserSecret, faBars, faMagnifyingGlass, faBell } from '@fortawesome/free-solid-svg-icons'
import "./dashboard-globals.css"
const PAGE_TITLES: Record<string,string> = {
  '/dashboard':'Dashboard',
  '/dashboard/discover':'Discover Members','/dashboard/network':'My Network',
  '/dashboard/referrals':'Referrals','/dashboard/groups':'Groups','/dashboard/attendance':'Attendance',
  '/dashboard/events':'Events','/dashboard/meetings':'Digital Meetings','/dashboard/learning':'Learning Ground',
  '/dashboard/travel':'Travel Connect','/dashboard/messages':'Messages','/dashboard/bizhub':'Business Hub',
  '/dashboard/profile':'My Profile','/dashboard/payments':'Payments','/dashboard/notifications':'Notifications',
  '/dashboard/analytics':'Analytics','/dashboard/settings':'Settings',
  '/dashboard/merch':'NetworkX Store','/dashboard/dealhub':'Deal Corner',
  '/dashboard/coord/members':'Members','/dashboard/coord/visitors':'Visitors',
  '/dashboard/coord/analytics':'Performance Analytics','/dashboard/coord/surveys':'Surveys',
  '/dashboard/coord/finance':'Finance Overview','/dashboard/coord/awards':'Awards',
  '/dashboard/coord/directory':'Directory & Roster',
  '/dashboard/coord/meetings':'Meeting Control',
  '/dashboard/coord/alerts':'Alerts',
  '/dashboard/coord/reports':'Reports',
  '/dashboard/franchise/meetings':'Meeting Management',
  '/dashboard/franchise/events':'Events Control',
  '/dashboard/franchise/expansion':'Expansion Engine',
  '/dashboard/hq/expansion':'Expansion Engine',
  '/dashboard/franchise/groups':'Groups','/dashboard/franchise/members':'Members',
  '/dashboard/franchise/finance':'Finance','/dashboard/franchise/reports':'Reports',
  '/dashboard/franchise/crm':'CRM','/dashboard/franchise/awards':'Awards',
  '/dashboard/hq':'HQ Control','/dashboard/hq/regions':'Regions','/dashboard/hq/groups':'Groups',
  '/dashboard/hq/members':'Members','/dashboard/hq/referrals':'Referrals','/dashboard/hq/tiers':'Membership Tiers','/dashboard/hq/verification':'Verification Queue','/dashboard/hq/franchise-applications':'Franchise Applications','/dashboard/hq/master-data':'Master Data',
  '/dashboard/hq/awards':'Points & Awards','/dashboard/hq/finance':'Finance Control',
  '/dashboard/hq/surveys':'Surveys','/dashboard/hq/directory':'Directory',
  '/dashboard/hq/settings':'System Settings','/dashboard/hq/admin':'Admin Controls',
  '/dashboard/super/users':'User Management','/dashboard/super/audit':'Audit Logs',
  '/dashboard/super/health':'System Health','/dashboard/super/toggles':'Feature Toggles',
}

export default function DashboardLayout({ children }: { children: React.ReactNode }) {
  const [user, setUser] = useState<User|null>(null)
  const [title, setTitle] = useState('Dashboard')
  const [impersonating, setImpersonating] = useState(false)
  const [origName, setOrigName] = useState('')
  const [sidebarOpen, setSidebarOpen] = useState(false)
  // Same bug fix as Sidebar.tsx — this topbar avatar was also always a
  // plain colored circle, regardless of whether a real photo was
  // uploaded. Separate fetch since this layout doesn't already call
  // ProfileAPI elsewhere (Sidebar.tsx has its own instance for the
  // profile-completion bar, so this isn't a duplicate of that one).
  const [avatarUrl, setAvatarUrl] = useState('')

  useEffect(() => {
    const u = getUser()
    if (!u) { window.location.href = '/login'; return }
    setUser(u)
    ProfileAPI.get().then((p: any) => setAvatarUrl(p?.avatar_url || '')).catch(() => {})
    const path = window.location.pathname.replace(/\/$/, '')
    setTitle(PAGE_TITLES[path] || 'Dashboard')

    setImpersonating(TokenStore.isImpersonating())
    try {
      const orig = JSON.parse(localStorage.getItem('nia_orig_user') || 'null')
      if (orig?.name) setOrigName(orig.name)
    } catch {}

    // Start automatic token refresh — refreshes 2min before expiry (15min tokens)
    initAutoRefresh(15)

    // Cleanup on unmount
    return () => stopAutoRefresh()
  }, [])

  const exitImpersonation = () => {
    TokenStore.exitImpersonation()
    window.location.href = '/dashboard/super/users'
  }

  // Always render same shell on server and client — no conditional structure
  return (
    <div className="shell" suppressHydrationWarning>
      <div className={`sb-backdrop${sidebarOpen ? ' open' : ''}`} onClick={()=>setSidebarOpen(false)}/>
      <Sidebar mobileOpen={sidebarOpen}/>
      <div className="main" suppressHydrationWarning>
        {impersonating && (
          <div style={{background:'#7c2d12',color:'#fff',padding:'8px 20px',display:'flex',alignItems:'center',justifyContent:'space-between',fontSize:13,flexShrink:0}}>
            <span><FontAwesomeIcon icon={faUserSecret} className="mr-1.5"/>Logged in as <strong>{user?.name}</strong> (impersonating{origName?` — real account: ${origName}`:''}). This session is fully audited and expires automatically.</span>
            <button onClick={exitImpersonation} style={{background:'var(--nx-panel)',color:'#7c2d12',border:'none',borderRadius:6,padding:'4px 12px',fontWeight:700,fontSize:12,cursor:'pointer'}}>Exit to my account</button>
          </div>
        )}
        <div className="topbar" suppressHydrationWarning>
          {user ? (
            <>
              <button className="sb-toggle" onClick={()=>setSidebarOpen(o=>!o)} aria-label="Toggle menu"><FontAwesomeIcon icon={faBars}/></button>
              <div style={{fontWeight:700,fontSize:16,color:'var(--nx-ink)'}}>{title}</div>
              <div style={{flex:1,display:'flex',alignItems:'center',gap:8,background:'var(--nx-panel2)',borderRadius:10,padding:'7px 14px',maxWidth:300,marginLeft:16}}>
                <span style={{color:'var(--nx-muted)',fontSize:13}}><FontAwesomeIcon icon={faMagnifyingGlass}/></span>
                <input
                  placeholder="Search members, groups, events…"
                  style={{border:'none',background:'transparent',outline:'none',fontSize:13,color:'var(--nx-ink)',padding:0,width:'100%'}}
                  onKeyDown={(e)=>{
                    if(e.key==='Enter'){
                      const q=(e.target as HTMLInputElement).value.trim().toLowerCase()
                      if(!q) return
                      if(['member','members','people','network'].some(k=>q.includes(k))) window.location.href='/dashboard/discover'
                      else if(['group','groups','chapter'].some(k=>q.includes(k))) window.location.href='/dashboard/groups'
                      else if(['referral','referrals','refer'].some(k=>q.includes(k))) window.location.href='/dashboard/referrals'
                      else if(['event','events','meet','meeting'].some(k=>q.includes(k))) window.location.href='/dashboard/events'
                      else if(['pay','payment','invoice','renew'].some(k=>q.includes(k))) window.location.href='/dashboard/payments'
                      else if(['learn','course','training'].some(k=>q.includes(k))) window.location.href='/dashboard/learning'
                      else if(['travel','trip','visit'].some(k=>q.includes(k))) window.location.href='/dashboard/travel'
                      else if(['message','chat','inbox'].some(k=>q.includes(k))) window.location.href='/dashboard/messages'
                      else if(['business','hub','opportunity'].some(k=>q.includes(k))) window.location.href='/dashboard/bizhub'
                      else if(['notif','notification','alert'].some(k=>q.includes(k))) window.location.href='/dashboard/notifications'
                      else window.location.href='/dashboard/discover'
                    }
                  }}
                />
              </div>
              <div style={{marginLeft:'auto',display:'flex',alignItems:'center',gap:14}}>
                <button style={{background:'none',border:'none',cursor:'pointer',position:'relative'}} onClick={()=>{ window.location.href='/dashboard/notifications' }}>
                  <span style={{fontSize:20}}><FontAwesomeIcon icon={faBell}/></span>
                  <span style={{position:'absolute',top:-2,right:-2,width:8,height:8,background:'var(--nx-orange)',borderRadius:'50%'}}/>
                </button>
                <div style={{display:'flex',alignItems:'center',gap:8,cursor:'pointer'}} onClick={()=>{ window.location.href='/dashboard/profile' }}>
                  <div className="av" style={{width:34,height:34,fontSize:12,background:'var(--nx-orange)',overflow:'hidden'}}>
                    {avatarUrl ? <img src={avatarUrl} alt={user.name} style={{width:'100%',height:'100%',objectFit:'cover'}}/> : user.avatar}
                  </div>
                  <div>
                    <div style={{fontSize:13,fontWeight:600}}>{user.name.split(' ')[0]}</div>
                    <div style={{fontSize:10,color:'#9ca3af',textTransform:'capitalize'}}>{user.role.replace('_',' ')}</div>
                  </div>
                </div>
              </div>
            </>
          ) : (
            <div style={{height:56}}/>
          )}
        </div>
        <div className="content" suppressHydrationWarning>{children}</div>
      </div>
    </div>
  )
}