import type { Metadata } from "next";
import Link from "next/link";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import { faArrowRight, faCheck, faXmark } from "@fortawesome/free-solid-svg-icons";

export const metadata: Metadata = {
  title: "Pricing | NetworkX",
  description: "Choose the NetworkX membership plan that fits your business journey.",
};

type Plan = {
  name: string;
  price: string;
  audience: string;
  description: string;
  popular?: boolean;
  features: string[];
};

const plans: Plan[] = [
  {
    name: "Connect",
    price: "₹1,999",
    audience: "Best for individuals",
    description: "Build your trusted business network and access the essential NetworkX community tools.",
    features: ["Community introductions", "WhatsApp digital community", "Mobile app and NetworkX CRM", "Referral chapters", "Free learning courses", "Membership card and sticker", "Business Hub view access", "Monthly live training"],
  },
  {
    name: "Growth",
    price: "₹4,999",
    audience: "Best for growing businesses",
    description: "Unlock intelligent matching, opportunities and full learning access to accelerate your growth.",
    popular: true,
    features: ["Everything in Connect", "AI member matching", "Co-founder matchmaking", "Deal Corner and investor circles", "Member spotlight opportunities", "Full LMS course access", "Business Hub view and post", "Free state summit invitations"],
  },
  {
    name: "Elite",
    price: "₹9,999",
    audience: "Best for serious founders",
    description: "A premium membership for ambitious founders seeking visibility, access and deeper collaboration.",
    features: ["Everything in Growth", "Priority founder positioning", "Speaking opportunity selection", "Full learning access", "Complete membership merchandise", "Business Hub view and post", "National summit benefits", "GeM portal support add-on"],
  },
];

type ComparisonRow = { feature: string; connect: boolean | string; growth: boolean | string; elite: boolean | string };

const comparisonGroups: { title: string; rows: ComparisonRow[] }[] = [
  {
    title: "Community & Networking",
    rows: [
      { feature: "Introductions posted in the community", connect: true, growth: true, elite: true },
      { feature: "WhatsApp digital community", connect: true, growth: true, elite: true },
      { feature: "Mobile app access", connect: true, growth: true, elite: true },
      { feature: "NetworkX CRM — meetings and follow-ups", connect: true, growth: true, elite: true },
      { feature: "Referral chapters", connect: true, growth: true, elite: true },
      { feature: "AI member matching", connect: false, growth: true, elite: true },
      { feature: "Co-founder matchmaking", connect: false, growth: true, elite: true },
      { feature: "Deal Corner — member offers and discounts", connect: false, growth: true, elite: true },
      { feature: "Investor reachout and VC circles", connect: false, growth: true, elite: true },
      { feature: "Member Spotlight on the app", connect: false, growth: true, elite: true },
      { feature: "Speaking opportunities", connect: false, growth: "Selection", elite: "Selection" },
    ],
  },
  {
    title: "Learning, Membership & Business Tools",
    rows: [
      { feature: "Online learning sessions with certificate", connect: "Free courses", growth: "Full access", elite: "Full access" },
      { feature: "Membership card / 25 business cards", connect: "Included", growth: "Included", elite: "Included" },
      { feature: "NetworkX member sticker", connect: "Included", growth: "Included", elite: "Included" },
      { feature: "Round-neck NetworkX T-shirt", connect: "Buy", growth: "Included", elite: "Included" },
      { feature: "NetworkX official pin", connect: "Buy", growth: "Included", elite: "Included" },
      { feature: "Business Hub requirement posts", connect: "View only", growth: "View & post", elite: "View & post" },
      { feature: "Monthly online live training", connect: "Included", growth: "Included", elite: "Included" },
    ],
  },
  {
    title: "Events & Founder Access",
    rows: [
      { feature: "National Summit invitation benefit", connect: "25%", growth: "50%", elite: "50%" },
      { feature: "State Summit invitations", connect: "50%", growth: "Included", elite: "Included" },
      { feature: "Pitch practice — online", connect: "Paid", growth: "Paid", elite: "Paid" },
      { feature: "Annual Award Night", connect: "Paid", growth: "Paid", elite: "Paid" },
      { feature: "GeM portal support app", connect: false, growth: false, elite: "Paid add-on" },
    ],
  },
];

function Value({ value }: { value: boolean | string }) {
  if (value === true) return <span className="compare-yes" aria-label="Included"><FontAwesomeIcon icon={faCheck} /></span>;
  if (value === false) return <span className="compare-no" aria-label="Not included"><FontAwesomeIcon icon={faXmark} /></span>;
  return <span className="compare-text">{value}</span>;
}

export default function PricingPage() {
  return (
    <main className="pricing-page">
      <header className="pricing-header">
        <Link href="/" className="pricing-logo" aria-label="NetworkX home"><img src="/brand/networkx-logo-header.png" alt="NetworkX" width="620" height="100" /></Link>
        <nav className="pricing-nav" aria-label="Primary navigation">
          <Link href="/">Home</Link><Link href="/about">About</Link><Link href="/#solutions">Solutions</Link><Link href="/#community">Community</Link><Link href="/#resources">Resources</Link><Link className="active" href="/pricing">Pricing</Link><Link href="/#contact">Contact</Link>
        </nav>
        <a className="button pricing-header-cta" href="mailto:hello@networkxcircle.com">Join NetworkX <span>↗</span></a>
        <details className="pricing-mobile-menu">
          <summary aria-label="Open navigation"><i /><i /></summary>
          <nav><Link href="/">Home</Link><Link href="/about">About</Link><Link href="/#solutions">Solutions</Link><Link href="/#community">Community</Link><Link href="/#resources">Resources</Link><Link href="/pricing">Pricing</Link><Link href="/#contact">Contact</Link></nav>
        </details>
      </header>

      <section className="pricing-hero">
        <div className="pricing-kicker">MEMBERSHIP PLANS</div>
        <h1>Choose the plan that<br /><em>moves you forward.</em></h1>
        <p>Start building meaningful business relationships today. Every NetworkX plan includes the core community experience, with more intelligence, access and visibility as you grow.</p>
        <div className="annual-pill">Annual membership · One simple payment</div>
      </section>

      <section className="pricing-cards" aria-label="NetworkX membership plans">
        {plans.map((plan) => (
          <article className={`pricing-card${plan.popular ? " popular" : ""}`} key={plan.name}>
            {plan.popular && <span className="popular-badge">Most Popular</span>}
            <div className="plan-name">{plan.name}</div>
            <div className="plan-price"><strong>{plan.price}</strong><span>/ year</span></div>
            <p>{plan.description}</p>
            <div className="plan-audience">{plan.audience}</div>
            <a className={`button plan-button${plan.popular ? "" : " button-secondary"}`} href="mailto:hello@networkxcircle.com">Choose {plan.name}<FontAwesomeIcon icon={faArrowRight} /></a>
            <ul>{plan.features.map((feature) => <li key={feature}><span><FontAwesomeIcon icon={faCheck} /></span>{feature}</li>)}</ul>
          </article>
        ))}
      </section>

      <section className="comparison-section">
        <div className="comparison-heading"><div className="pricing-kicker">COMPARE BENEFITS</div><h2>Everything, side by side.</h2><p>Review the complete membership benefits and choose the access level that matches your ambitions.</p></div>
        <div className="comparison-scroll" role="region" aria-label="Scrollable plan comparison" tabIndex={0}>
          <table>
            <thead><tr><th>Benefits</th><th>Connect<br /><span>₹1,999</span></th><th className="growth-column">Growth<br /><span>₹4,999</span><em>Most Popular</em></th><th>Elite<br /><span>₹9,999</span></th></tr></thead>
            <tbody>
              {comparisonGroups.map((group) => (
                <FragmentGroup key={group.title} title={group.title} rows={group.rows} />
              ))}
              <tr className="best-for-row"><th>Best for</th><td>Individuals</td><td>Growing businesses</td><td>Serious founders</td></tr>
            </tbody>
          </table>
        </div>
        <p className="comparison-note">Membership benefits, event access and paid add-ons may be subject to availability and selection criteria.</p>
      </section>

      <section className="pricing-cta">
        <div><span>READY TO JOIN?</span><h2>Your next opportunity starts with one connection.</h2><p>Choose your NetworkX membership and start building what’s next.</p></div>
        <a className="button" href="mailto:hello@networkxcircle.com">Talk to our team <FontAwesomeIcon icon={faArrowRight} /></a>
      </section>

      <footer className="pricing-footer">
        <Link href="/" aria-label="NetworkX home"><img src="/brand/networkx-logo-header.png" alt="NetworkX" width="620" height="100" /></Link>
        <p>© 2026 NetworkX. All rights reserved.</p>
        <nav><Link href="/about">About</Link><Link href="/#community">Community</Link><Link href="/#contact">Contact</Link><Link href="/pricing">Pricing</Link></nav>
      </footer>
    </main>
  );
}

function FragmentGroup({ title, rows }: { title: string; rows: ComparisonRow[] }) {
  return (
    <>
      <tr className="comparison-group"><th colSpan={4}>{title}</th></tr>
      {rows.map((row) => <tr key={row.feature}><th>{row.feature}</th><td><Value value={row.connect} /></td><td><Value value={row.growth} /></td><td><Value value={row.elite} /></td></tr>)}
    </>
  );
}
