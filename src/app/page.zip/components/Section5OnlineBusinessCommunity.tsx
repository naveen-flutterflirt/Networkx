const assetRoot = "/images/section-5-online";

const topRoles = [
  { label: "Professionals", icon: "icon-professionals.svg", tone: "orange" },
  { label: "Entrepreneurs", icon: "icon-entrepreneurs.svg", tone: "blue" },
  { label: "Business Owners", icon: "icon-business-owners.svg", tone: "green" },
  { label: "Mentors", icon: "icon-mentors.svg", tone: "purple" },
  { label: "Investors", icon: "icon-investors.svg", tone: "gold" },
  { label: "Industry Experts", icon: "icon-industry-experts.svg", tone: "cyan" },
];

const bottomPillars = [
  {
    title: "Diverse by Design",
    copy: "Different industries, markets and professional backgrounds.",
    icon: "icon-diverse.svg",
    tone: "blue",
  },
  {
    title: "Business-First Community",
    copy: "Built around meaningful professional relationships and opportunities.",
    icon: "icon-business-first.svg",
    tone: "orange",
  },
  {
    title: "Global Reach. Local Relevance.",
    copy: "Connect globally while discovering people relevant to your city, industry and goals.",
    icon: "icon-global-reach.svg",
    tone: "green",
  },
];

export default function Section5OnlineBusinessCommunity() {
  return (
    <section className="s5-community" id="community" aria-labelledby="s5-community-title">
      <div className="s5-community-inner">
        <div className="s5-community-top">
          <div className="s5-community-intro">
            <div className="s5-community-eyebrow"><i />A global business community<i /></div>
            <h2 id="s5-community-title">
              Built Across Countries.<br />
              Connected Across Industries.<br />
              <span>United by Growth.</span>
            </h2>
            <p>NetworkX brings professionals, entrepreneurs, business owners, solopreneurs, mentors, investors and industry experts together in one trusted online business ecosystem.</p>
          </div>

          <div className="s5-role-grid" aria-label="Who NetworkX is for">
            {topRoles.map((role) => (
              <article className={`s5-role s5-tone-${role.tone}`} key={role.label}>
                <span className="s5-role-icon" aria-hidden="true">
                  <img src={`${assetRoot}/${role.icon}`} alt="" />
                </span>
                <h3>{role.label}</h3>
              </article>
            ))}
          </div>
        </div>

        <div className="s5-mosaic-reference-wrap" aria-label="A diverse global NetworkX business community">
          <img
            className="s5-mosaic-reference"
            src={`${assetRoot}/section5-mosaic-reference.png`}
            alt="NetworkX professionals from diverse countries and industries in one online business community"
          />
        </div>

        <div className="s5-pillar-strip">
          {bottomPillars.map((pillar) => (
            <article key={pillar.title} className={`s5-tone-${pillar.tone}`}>
              <span aria-hidden="true"><img src={`${assetRoot}/${pillar.icon}`} alt="" /></span>
              <div><h3>{pillar.title}</h3><p>{pillar.copy}</p></div>
            </article>
          ))}
        </div>

        <div className="s5-community-closing">
          <i /><span aria-hidden="true"><img src={`${assetRoot}/icon-community.svg`} alt="" /></span>
          <strong>Real People. Diverse Businesses. Shared Ambition. <em>One NetworkX.</em></strong><i />
        </div>
      </div>
    </section>
  );
}
