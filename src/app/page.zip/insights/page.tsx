"use client";

import { useEffect, useState } from "react";
import InsightCard from "@/components/InsightCard";
import InsightsHeader from "@/components/InsightsHeader";

type Insight = {
  slug: string;
  category: string;
  title: string;
  excerpt: string;
  cover: string;
  readingTime: string;
  seoTitle: string;
  metaDescription: string;
  primaryKeyword: string;
  secondaryKeywords: string[];
  ogImage: string;
  h1: string;
};

// TODO: point this at your real FastAPI base URL (e.g. NEXT_PUBLIC_API_BASE_URL)
const API_BASE = process.env.NEXT_PUBLIC_API_BASE_URL ?? "";

export default function InsightsIndexPage() {
  const [insights, setInsights] = useState<Insight[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    let cancelled = false;

    async function loadInsights() {
      try {
        setLoading(true);
        setError(null);
        // TODO: replace with your actual insights list endpoint
        const res = await fetch(`${API_BASE}/api/insights`, { cache: "no-store" });
        if (!res.ok) throw new Error(`Failed to load insights (${res.status})`);
        const data: Insight[] = await res.json();
        if (!cancelled) setInsights(data);
      } catch (err) {
        if (!cancelled) {
          setError(err instanceof Error ? err.message : "Failed to load insights");
        }
      } finally {
        if (!cancelled) setLoading(false);
      }
    }

    loadInsights();
    return () => {
      cancelled = true;
    };
  }, []);

  const categories = Array.from(new Set(insights.map((insight) => insight.category)));

  return (
    <main className="insights-page">
      <InsightsHeader />
      <section className="insights-index-hero">
        <div className="insights-index-eyebrow">Insights &amp; Ideas</div>
        <h1>
          Insights for Smarter Networking
          <br />
          and <span>Business Growth</span>
        </h1>
        <p>Explore practical perspectives on AI, networking, global opportunities, partnerships and business growth.</p>
        {!loading && !error && categories.length > 0 && (
          <div className="insights-categories" aria-label="Insight categories">
            {categories.map((category) => (
              <span key={category}>{category}</span>
            ))}
          </div>
        )}
      </section>

      {loading && <p className="insights-status">Loading insights…</p>}
      {error && <p className="insights-status insights-status-error">{error}</p>}

      {!loading && !error && (
        <section className="insights-index-grid" aria-label="All NetworkX insights">
          {insights.map((insight) => (
            <InsightCard insight={insight} key={insight.slug} />
          ))}
        </section>
      )}

      <section className="insights-index-cta">
        <div>
          <span>Learn. Build. Evolve.</span>
          <h2>Turn better ideas into better connections.</h2>
        </div>
        <a href="mailto:hello@networkxcircle.com">Join NetworkX →</a>
      </section>
    </main>
  );
}
