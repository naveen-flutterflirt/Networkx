"use client";

import { useEffect, useState } from "react";
import Image from "next/image";
import Link from "next/link";
import { useParams } from "next/navigation";
import InsightCard from "@/components/InsightCard";
import InsightsHeader from "@/components/InsightsHeader";

type ContentSection = {
  heading?: string;
  paragraphs?: string[];
  list?: string[];
  emphasis?: string;
};

type Insight = {
  slug: string;
  category: string;
  title: string;
  excerpt: string;
  cover: string;
  readingTime: string;
  seoTitle: string;
  metaDescription: string;
  primaryKeyword: string;
  secondaryKeywords: string[];
  ogImage: string;
  h1: string;
};

type InsightDetailResponse = {
  insight: Insight;
  content: ContentSection[];
  related: Insight[];
};

// TODO: point this at your real FastAPI base URL (e.g. NEXT_PUBLIC_API_BASE_URL)
const API_BASE = process.env.NEXT_PUBLIC_API_BASE_URL ?? "";
const siteUrl = "https://networkx-connected-enterprise.dhiyotech.chatgpt.site";

export default function InsightArticlePage() {
  const params = useParams<{ slug: string }>();
  const slug = params?.slug as string | undefined;

  const [data, setData] = useState<InsightDetailResponse | null>(null);
  const [loading, setLoading] = useState(true);
  const [isMissing, setIsMissing] = useState(false);

  useEffect(() => {
    if (!slug) return;
    let cancelled = false;

    async function loadInsight() {
      try {
        setLoading(true);
        setIsMissing(false);
        // TODO: replace with your actual insight-by-slug endpoint
        const res = await fetch(`${API_BASE}/api/insights/${slug}`, { cache: "no-store" });
        if (res.status === 404) {
          if (!cancelled) setIsMissing(true);
          return;
        }
        if (!res.ok) throw new Error(`Failed to load insight (${res.status})`);
        const json: InsightDetailResponse = await res.json();
        if (!cancelled) setData(json);
      } catch {
        if (!cancelled) setIsMissing(true);
      } finally {
        if (!cancelled) setLoading(false);
      }
    }

    loadInsight();
    return () => {
      cancelled = true;
    };
  }, [slug]);

  // Client components can't export generateMetadata, so set title/description
  // on the client once the insight loads (SEO impact — see note below).
  useEffect(() => {
    if (!data?.insight) return;
    document.title = data.insight.seoTitle;
    const metaDesc = document.querySelector('meta[name="description"]');
    if (metaDesc) metaDesc.setAttribute("content", data.insight.metaDescription);
  }, [data]);

  if (loading) {
    return (
      <main className="insights-page insight-article-page">
        <InsightsHeader />
        <p className="insights-status">Loading insight…</p>
      </main>
    );
  }

  if (isMissing || !data) {
    return (
      <main className="insights-page insight-article-page">
        <InsightsHeader />
        <p className="insights-status insights-status-error">Insight not found.</p>
        <Link href="/insights">Back to Insights</Link>
      </main>
    );
  }

  const { insight, content, related } = data;
  const canonical = `${siteUrl}/insights/${insight.slug}`;
  const structuredData = {
    "@context": "https://schema.org",
    "@type": "BlogPosting",
    headline: insight.h1,
    description: insight.metaDescription,
    image: `${siteUrl}${insight.ogImage}`,
    author: { "@type": "Organization", name: "NetworkX" },
    publisher: {
      "@type": "Organization",
      name: "NetworkX",
      logo: { "@type": "ImageObject", url: `${siteUrl}/brand/networkx-logo-header.png` },
    },
    mainEntityOfPage: canonical,
  };

  return (
    <main className="insights-page insight-article-page">
      <InsightsHeader />
      <script type="application/ld+json" dangerouslySetInnerHTML={{ __html: JSON.stringify(structuredData) }} />
      <article className="insight-article">
        <nav className="insight-breadcrumbs" aria-label="Breadcrumb">
          <Link href="/">Home</Link>
          <span>/</span>
          <Link href="/insights">Insights</Link>
          <span>/</span>
          <b>{insight.category}</b>
        </nav>
        <header className="insight-article-header">
          <span className="insight-article-category">{insight.category}</span>
          <h1>{insight.h1}</h1>
          <p>{insight.excerpt}</p>
          <div>
            <span>By NetworkX</span>
            <i /> <span>{insight.readingTime}</span>
          </div>
        </header>
        <div className="insight-article-cover">
          <Image src={insight.cover} alt={`${insight.title} cover illustration`} fill priority sizes="(max-width: 900px) 100vw, 1080px" />
        </div>
        <div className="insight-article-body">
          {content.map((section, index) => (
            <section key={`${section.heading ?? "introduction"}-${index}`}>
              {section.heading && <h2>{section.heading}</h2>}
              {section.paragraphs?.map((paragraph) => (
                <p key={paragraph}>{paragraph}</p>
              ))}
              {section.list && (
                <ul>
                  {section.list.map((item) => (
                    <li key={item}>{item}</li>
                  ))}
                </ul>
              )}
              {section.emphasis && <blockquote>{section.emphasis}</blockquote>}
            </section>
          ))}
          <nav className="insight-topic-links" aria-label="Explore NetworkX features">
            <span>Explore related NetworkX experiences</span>
            <div>
              <Link href="/#solutions">AI matchmaking</Link>
              <Link href="/#global-community">Global community</Link>
              <Link href="/#membership">Memberships</Link>
            </div>
          </nav>
          <aside className="insight-inline-cta">
            <span>Explore NetworkX</span>
            <h2>Build smarter connections and discover relevant opportunities.</h2>
            <Link href="/#membership">Explore Memberships →</Link>
          </aside>
        </div>
      </article>
      <section className="related-insights">
        <header>
          <span>Keep exploring</span>
          <h2>Related insights</h2>
        </header>
        <div>
          {related.map((item) => (
            <InsightCard insight={item} key={item.slug} />
          ))}
        </div>
      </section>
    </main>
  );
}
