'use client'
import { useState, useEffect } from 'react'
// import { PublicAPI } from '@/lib/api'
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome'
import { faCircleCheck, faCircleXmark, faSpinner, faTriangleExclamation } from '@fortawesome/free-solid-svg-icons'

const TIER_LABEL: Record<string,string> = {
  connect:'Connect', growth:'Growth', elite:'Elite',
  city_leadership:'City Leadership', national:'National', global:'Global',
}

export default function PlansPage() {
  const [tiers, setTiers] = useState<any[]>([])
  const [permissionLabels, setPermissionLabels] = useState<Record<string,string>>({})
  const [tierOrder, setTierOrder] = useState<string[]>([])
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState('')
  const [expanded, setExpanded] = useState<string|null>(null)

  useEffect(() => {
    // PublicAPI.tiers()
    //   .then((res: any) => {
    //     setTiers(res.tiers || [])
    //     setPermissionLabels(res.permission_labels || {})
    //     setTierOrder(res.tier_order || [])
    //   })
    //   .catch((e: any) => setError(e.message))
    //   .finally(() => setLoading(false))
  }, [])

  const ordered = tierOrder.length ? tierOrder.map(t => tiers.find(x => x.tier === t)).filter(Boolean) : tiers

  return (
    <div className="min-h-screen bg-night text-ink">
      {/* Header */}
      <div className="max-w-6xl mx-auto px-6 pt-16 pb-10 text-center">
        <div className="text-orange text-xs font-bold tracking-[.18em] uppercase mb-3">Membership Plans</div>
        <h1 className="text-4xl md:text-5xl font-extrabold tracking-tight mb-4">Compare all NetworkX tiers</h1>
        <p className="text-muted text-base max-w-2xl mx-auto">
          Every tier's real price and what it actually unlocks — pulled live from the same system HQ manages, not a static page that drifts out of date.
        </p>
      </div>

      <div className="max-w-6xl mx-auto px-6 pb-24">
        {loading && (
          <div className="flex items-center justify-center gap-3 py-24 text-muted">
            <FontAwesomeIcon icon={faSpinner} className="animate-spin"/> Loading plans…
          </div>
        )}

        {error && (
          <div className="flex items-center justify-center gap-3 py-24 text-red-300">
            <FontAwesomeIcon icon={faTriangleExclamation}/> Couldn't load plans right now — {error}
          </div>
        )}

        {!loading && !error && (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-5">
            {ordered.map((t: any) => {
              const needsPricing = t.price_numeric == null
              const isExpanded = expanded === t.tier
              const benefitEntries = Object.entries(t.benefits || {})

              return (
                <div key={t.tier} className="rounded-2xl border border-line bg-panel p-6 shadow-card flex flex-col">
                  <div className="flex items-center justify-between mb-1">
                    <div className="text-lg font-bold">{TIER_LABEL[t.tier] || t.tier}</div>
                    <span className={`text-[10px] font-bold uppercase tracking-wide px-2 py-1 rounded-full ${t.type === 'Digital' ? 'bg-blue/15 text-blue' : 'bg-orange/15 text-orange'}`}>
                      {t.type}
                    </span>
                  </div>

                  {needsPricing ? (
                    <div className="text-amber-400 text-sm font-semibold mt-3 mb-1">Contact us for pricing</div>
                  ) : (
                    <div className="mt-3 mb-1">
                      <span className="text-3xl font-extrabold text-orange">{t.price}</span>
                      <span className="text-muted text-sm"> /year</span>
                    </div>
                  )}
                  <div className="h-px bg-line my-4"/>

                  {/* Real, enforced permissions */}
                  <div className="text-[11px] font-bold text-muted uppercase tracking-wide mb-2.5">What this tier unlocks</div>
                  <div className="flex flex-col gap-2.5 mb-4">
                    {Object.entries(permissionLabels).map(([key, label]) => {
                      const has = !!t.permissions?.[key]
                      return (
                        <div key={key} className="flex items-start gap-2.5">
                          <FontAwesomeIcon icon={has ? faCircleCheck : faCircleXmark} className={`mt-0.5 flex-shrink-0 ${has ? 'text-green' : 'text-muted/50'}`}/>
                          <span className={`text-[13px] leading-snug ${has ? 'text-ink' : 'text-muted/70'}`}>{label as string}</span>
                        </div>
                      )
                    })}
                    {Object.keys(permissionLabels).length === 0 && (
                      <div className="text-xs text-muted">No gated permissions configured yet.</div>
                    )}
                  </div>

                  {/* Benefits — collapsed by default, expandable */}
                  {benefitEntries.length > 0 && (
                    <div className="mt-auto pt-3 border-t border-line">
                      <button
                        onClick={() => setExpanded(isExpanded ? null : t.tier)}
                        className="text-xs font-semibold text-orange hover:text-orange/80 transition-colors">
                        {isExpanded ? 'Hide' : 'Show'} all {benefitEntries.length} benefits {isExpanded ? '▲' : '▼'}
                      </button>
                      {isExpanded && (
                        <div className="mt-3 flex flex-col gap-2 max-h-64 overflow-y-auto pr-1">
                          {benefitEntries.map(([name, value]) => (
                            <div key={name} className="flex items-start justify-between gap-3 text-xs">
                              <span className="text-muted">{name}</span>
                              <span className={`font-semibold flex-shrink-0 text-right ${value === '❌' || !value ? 'text-muted/50' : 'text-ink'}`}>
                                {String(value || '—')}
                              </span>
                            </div>
                          ))}
                        </div>
                      )}
                    </div>
                  )}
                </div>
              )
            })}
          </div>
        )}
      </div>
    </div>
  )
}
